package com.rbook.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
