import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.rbook.app',
  appName: 'RBook',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
