import {
  db,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  addDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  serverTimestamp,
  arrayUnion,
  arrayRemove,
  increment,
  limit
} from '../lib/firebase';
import { UserProfile, Post, Comment, NotificationItem, ChatRoom, Message, Report } from '../types';

// Default Avatars & Media Stock
export const DEFAULT_AVATARS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
];

export const DEFAULT_COVER = 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop&q=80';

// Sample feed posts to populate new installation
export const SAMPLE_POSTS: Omit<Post, 'id'>[] = [
  {
    authorId: 'rbook-official',
    authorName: 'RBook Community',
    authorPhoto: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
    content: 'Welcome to RBook! 🚀 Connect with friends, share photos and videos, chat in real-time, and stay updated with live notifications. Enjoy your social hub!',
    mediaType: 'image',
    mediaUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1000&auto=format&fit=crop&q=80',
    likesCount: 12,
    likes: ['rbook-official'],
    commentsCount: 3,
    sharesCount: 5,
    createdAt: new Date().toISOString()
  },
  {
    authorId: 'alex-morgan',
    authorName: 'Alex Morgan',
    authorPhoto: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    content: 'Sunset hike in the mountains today! The view was absolutely breath-taking 🌄 Who else loves outdoor adventures?',
    mediaType: 'image',
    mediaUrl: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1000&auto=format&fit=crop&q=80',
    likesCount: 24,
    likes: [],
    commentsCount: 5,
    sharesCount: 2,
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString()
  },
  {
    authorId: 'sarah-jenkins',
    authorName: 'Sarah Jenkins',
    authorPhoto: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    content: 'Check out this awesome sample video from our tech setup! 💻📱 Drop a comment on what tech gear you use daily.',
    mediaType: 'video',
    mediaUrl: 'https://assets.mixkit.co/videos/preview/mixkit-working-overtime-in-a-modern-office-42511-large.mp4',
    likesCount: 18,
    likes: [],
    commentsCount: 2,
    sharesCount: 1,
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString()
  }
];

// --- USER PROFILE SERVICES ---

export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  try {
    const userDoc = await getDoc(doc(db, 'users', uid));
    if (userDoc.exists()) {
      return userDoc.data() as UserProfile;
    }
    return null;
  } catch (error) {
    console.error('Error getting user profile:', error);
    return null;
  }
}

export async function createUserProfile(profile: Partial<UserProfile> & { uid: string; email: string; displayName: string }): Promise<UserProfile> {
  const newUser: UserProfile = {
    uid: profile.uid,
    displayName: profile.displayName || 'RBook User',
    email: profile.email,
    photoURL: profile.photoURL || DEFAULT_AVATARS[0],
    coverPhotoURL: profile.coverPhotoURL || DEFAULT_COVER,
    bio: profile.bio || 'Hello! I am new on RBook.',
    location: profile.location || 'Earth',
    website: profile.website || '',
    followersCount: 0,
    followingCount: 0,
    followers: [],
    following: [],
    blockedUsers: [],
    online: true,
    lastSeen: new Date().toISOString(),
    createdAt: new Date().toISOString()
  };

  try {
    await setDoc(doc(db, 'users', profile.uid), newUser);
  } catch (e) {
    console.warn('Failed to save user doc to Firestore:', e);
  }

  return newUser;
}

export async function updateUserProfile(uid: string, updates: Partial<UserProfile>): Promise<void> {
  try {
    const userRef = doc(db, 'users', uid);
    await updateDoc(userRef, updates);
  } catch (error) {
    console.error('Error updating profile:', error);
    throw error;
  }
}

export async function updateUserOnlineStatus(uid: string, isOnline: boolean): Promise<void> {
  try {
    const userRef = doc(db, 'users', uid);
    await updateDoc(userRef, {
      online: isOnline,
      lastSeen: new Date().toISOString()
    });
  } catch (e) {
    // ignore
  }
}

export async function searchUsers(searchTerm: string): Promise<UserProfile[]> {
  if (!searchTerm.trim()) return [];
  const term = searchTerm.toLowerCase();
  try {
    const usersRef = collection(db, 'users');
    const q = query(usersRef, limit(20));
    const snapshot = await getDocs(q);
    const results: UserProfile[] = [];
    snapshot.forEach((docSnap) => {
      const u = docSnap.data() as UserProfile;
      if (
        u.displayName?.toLowerCase().includes(term) ||
        u.email?.toLowerCase().includes(term) ||
        u.bio?.toLowerCase().includes(term)
      ) {
        results.push(u);
      }
    });
    return results;
  } catch (error) {
    console.error('Error searching users:', error);
    return [];
  }
}

// --- POST SERVICES ---

export async function createPost(postData: {
  authorId: string;
  authorName: string;
  authorPhoto: string;
  content: string;
  mediaType: 'image' | 'video' | 'none';
  mediaUrl?: string;
}): Promise<string> {
  const postsRef = collection(db, 'posts');
  const newPost = {
    ...postData,
    likesCount: 0,
    likes: [],
    commentsCount: 0,
    sharesCount: 0,
    createdAt: new Date().toISOString()
  };

  const docRef = await addDoc(postsRef, newPost);
  return docRef.id;
}

export async function deletePost(postId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'posts', postId));
  } catch (error) {
    console.error('Error deleting post:', error);
    throw error;
  }
}

export function subscribeToPosts(callback: (posts: Post[]) => void, blockedUsers: string[] = []) {
  const postsRef = collection(db, 'posts');
  const q = query(postsRef, orderBy('createdAt', 'desc'), limit(50));

  return onSnapshot(q, (snapshot) => {
    let postsList: Post[] = [];
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      if (!blockedUsers.includes(data.authorId)) {
        postsList.push({ id: docSnap.id, ...data } as Post);
      }
    });

    // If Firestore posts are empty on initial run, populate sample posts
    if (postsList.length === 0 && snapshot.empty) {
      postsList = SAMPLE_POSTS.map((sp, idx) => ({ id: `sample-${idx}`, ...sp }));
    }

    callback(postsList);
  }, (err) => {
    console.warn('Posts realtime listener error, falling back to sample feed:', err);
    callback(SAMPLE_POSTS.map((sp, idx) => ({ id: `sample-${idx}`, ...sp })));
  });
}

export async function toggleLikePost(postId: string, userId: string, isLiked: boolean, authorId?: string, userName?: string, userPhoto?: string): Promise<void> {
  if (postId.startsWith('sample-')) return; // Sample post memory handling
  const postRef = doc(db, 'posts', postId);
  try {
    if (isLiked) {
      await updateDoc(postRef, {
        likes: arrayRemove(userId),
        likesCount: increment(-1)
      });
    } else {
      await updateDoc(postRef, {
        likes: arrayUnion(userId),
        likesCount: increment(1)
      });

      // Send notification if liking someone else's post
      if (authorId && authorId !== userId) {
        createNotification({
          recipientId: authorId,
          senderId: userId,
          senderName: userName || 'Someone',
          senderPhoto: userPhoto || DEFAULT_AVATARS[0],
          type: 'like',
          postId,
          message: 'liked your post.',
          read: false,
          createdAt: new Date().toISOString()
        });
      }
    }
  } catch (error) {
    console.error('Error toggling post like:', error);
  }
}

export async function sharePost(postId: string): Promise<void> {
  if (postId.startsWith('sample-')) return;
  const postRef = doc(db, 'posts', postId);
  try {
    await updateDoc(postRef, {
      sharesCount: increment(1)
    });
  } catch (e) {
    console.warn('Share counter increment failed:', e);
  }
}

// --- COMMENT SERVICES ---

export function subscribeToComments(postId: string, callback: (comments: Comment[]) => void) {
  if (postId.startsWith('sample-')) {
    callback([
      {
        id: 'sample-comment-1',
        postId,
        authorId: 'alex-morgan',
        authorName: 'Alex Morgan',
        authorPhoto: DEFAULT_AVATARS[1],
        text: 'Awesome post! Love this!',
        createdAt: new Date(Date.now() - 1800000).toISOString()
      }
    ]);
    return () => {};
  }

  const commentsRef = collection(db, 'comments');
  const q = query(commentsRef, where('postId', '==', postId), orderBy('createdAt', 'asc'));

  return onSnapshot(q, (snapshot) => {
    const commentsList: Comment[] = [];
    snapshot.forEach((docSnap) => {
      commentsList.push({ id: docSnap.id, ...docSnap.data() } as Comment);
    });
    callback(commentsList);
  });
}

export async function addComment(commentData: {
  postId: string;
  authorId: string;
  authorName: string;
  authorPhoto: string;
  text: string;
  postAuthorId?: string;
}): Promise<void> {
  const { postAuthorId, ...data } = commentData;
  if (data.postId.startsWith('sample-')) return;

  const commentsRef = collection(db, 'comments');
  await addDoc(commentsRef, {
    ...data,
    createdAt: new Date().toISOString()
  });

  // Increment comments count on post
  const postRef = doc(db, 'posts', data.postId);
  await updateDoc(postRef, {
    commentsCount: increment(1)
  });

  // Send notification to post author
  if (postAuthorId && postAuthorId !== data.authorId) {
    createNotification({
      recipientId: postAuthorId,
      senderId: data.authorId,
      senderName: data.authorName,
      senderPhoto: data.authorPhoto,
      type: 'comment',
      postId: data.postId,
      message: `commented on your post: "${data.text.slice(0, 30)}..."`,
      read: false,
      createdAt: new Date().toISOString()
    });
  }
}

export async function deleteComment(commentId: string, postId: string): Promise<void> {
  if (commentId.startsWith('sample-')) return;
  await deleteDoc(doc(db, 'comments', commentId));
  const postRef = doc(db, 'posts', postId);
  await updateDoc(postRef, {
    commentsCount: increment(-1)
  });
}

// --- FOLLOW / UNFOLLOW SERVICES ---

export async function toggleFollowUser(currentUserId: string, targetUserId: string, isFollowing: boolean, currentUserName?: string, currentUserPhoto?: string): Promise<void> {
  const currentUserRef = doc(db, 'users', currentUserId);
  const targetUserRef = doc(db, 'users', targetUserId);

  try {
    if (isFollowing) {
      // Unfollow
      await updateDoc(currentUserRef, {
        following: arrayRemove(targetUserId),
        followingCount: increment(-1)
      });
      await updateDoc(targetUserRef, {
        followers: arrayRemove(currentUserId),
        followersCount: increment(-1)
      });
    } else {
      // Follow
      await updateDoc(currentUserRef, {
        following: arrayUnion(targetUserId),
        followingCount: increment(1)
      });
      await updateDoc(targetUserRef, {
        followers: arrayUnion(currentUserId),
        followersCount: increment(1)
      });

      // Send follow notification
      createNotification({
        recipientId: targetUserId,
        senderId: currentUserId,
        senderName: currentUserName || 'Someone',
        senderPhoto: currentUserPhoto || DEFAULT_AVATARS[0],
        type: 'follow',
        message: 'started following you.',
        read: false,
        createdAt: new Date().toISOString()
      });
    }
  } catch (error) {
    console.error('Error toggling follow:', error);
  }
}

// --- BLOCK USER & REPORT SERVICES ---

export async function blockUser(currentUserId: string, targetUserId: string): Promise<void> {
  try {
    const userRef = doc(db, 'users', currentUserId);
    await updateDoc(userRef, {
      blockedUsers: arrayUnion(targetUserId),
      following: arrayRemove(targetUserId)
    });
  } catch (error) {
    console.error('Error blocking user:', error);
  }
}

export async function unblockUser(currentUserId: string, targetUserId: string): Promise<void> {
  try {
    const userRef = doc(db, 'users', currentUserId);
    await updateDoc(userRef, {
      blockedUsers: arrayRemove(targetUserId)
    });
  } catch (error) {
    console.error('Error unblocking user:', error);
  }
}

export async function submitReport(report: Omit<Report, 'id' | 'createdAt'>): Promise<void> {
  try {
    const reportsRef = collection(db, 'reports');
    await addDoc(reportsRef, {
      ...report,
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error submitting report:', error);
    throw error;
  }
}

// --- NOTIFICATION SERVICES ---

export async function createNotification(notification: Omit<NotificationItem, 'id'>): Promise<void> {
  try {
    const notifRef = collection(db, 'notifications');
    await addDoc(notifRef, notification);
  } catch (e) {
    console.warn('Failed to save notification:', e);
  }
}

export function subscribeToNotifications(userId: string, callback: (notifs: NotificationItem[]) => void) {
  const notifRef = collection(db, 'notifications');
  const q = query(notifRef, where('recipientId', '==', userId), orderBy('createdAt', 'desc'), limit(30));

  return onSnapshot(q, (snapshot) => {
    const notifs: NotificationItem[] = [];
    snapshot.forEach((docSnap) => {
      notifs.push({ id: docSnap.id, ...docSnap.data() } as NotificationItem);
    });
    callback(notifs);
  }, (err) => {
    console.warn('Notification snapshot warning:', err);
    callback([]);
  });
}

export async function markNotificationAsRead(notifId: string): Promise<void> {
  try {
    await updateDoc(doc(db, 'notifications', notifId), { read: true });
  } catch (e) {
    // ignore
  }
}

export async function markAllNotificationsAsRead(userId: string): Promise<void> {
  try {
    const notifRef = collection(db, 'notifications');
    const q = query(notifRef, where('recipientId', '==', userId), where('read', '==', false));
    const snapshot = await getDocs(q);
    snapshot.forEach(async (d) => {
      await updateDoc(doc(db, 'notifications', d.id), { read: true });
    });
  } catch (e) {
    // ignore
  }
}

// --- CHAT SERVICES ---

export function getChatRoomId(uid1: string, uid2: string): string {
  return [uid1, uid2].sort().join('_');
}

export async function getOrCreateChatRoom(uid1: string, uid2: string): Promise<string> {
  const roomId = getChatRoomId(uid1, uid2);
  const roomRef = doc(db, 'chats', roomId);
  const snap = await getDoc(roomRef);

  if (!snap.exists()) {
    await setDoc(roomRef, {
      participants: [uid1, uid2],
      lastMessage: '',
      lastMessageTime: new Date().toISOString(),
      lastSenderId: uid1
    });
  }

  return roomId;
}

export function subscribeToUserChats(userId: string, callback: (chats: ChatRoom[]) => void) {
  const chatsRef = collection(db, 'chats');
  const q = query(chatsRef, where('participants', 'array-contains', userId));

  return onSnapshot(q, (snapshot) => {
    const chats: ChatRoom[] = [];
    snapshot.forEach((docSnap) => {
      chats.push({ id: docSnap.id, ...docSnap.data() } as ChatRoom);
    });
    callback(chats);
  });
}

export function subscribeToChatMessages(chatId: string, callback: (messages: Message[]) => void) {
  const messagesRef = collection(db, 'messages');
  const q = query(messagesRef, where('chatId', '==', chatId), orderBy('createdAt', 'asc'));

  return onSnapshot(q, (snapshot) => {
    const msgs: Message[] = [];
    snapshot.forEach((docSnap) => {
      msgs.push({ id: docSnap.id, ...docSnap.data() } as Message);
    });
    callback(msgs);
  });
}

export async function sendChatMessage(data: {
  chatId: string;
  senderId: string;
  receiverId: string;
  text: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video' | 'none';
  senderName?: string;
  senderPhoto?: string;
}): Promise<void> {
  const { senderName, senderPhoto, ...msgData } = data;
  const messagesRef = collection(db, 'messages');
  await addDoc(messagesRef, {
    ...msgData,
    createdAt: new Date().toISOString(),
    read: false
  });

  // Update chat room last message
  const roomRef = doc(db, 'chats', data.chatId);
  await updateDoc(roomRef, {
    lastMessage: data.text || (data.mediaType === 'image' ? '📷 Image' : '🎥 Video'),
    lastMessageTime: new Date().toISOString(),
    lastSenderId: data.senderId
  });

  // Send message notification
  createNotification({
    recipientId: data.receiverId,
    senderId: data.senderId,
    senderName: senderName || 'Someone',
    senderPhoto: senderPhoto || DEFAULT_AVATARS[0],
    type: 'message',
    message: `sent you a message: "${data.text.slice(0, 30) || 'Media content'}"`,
    read: false,
    createdAt: new Date().toISOString()
  });
}
