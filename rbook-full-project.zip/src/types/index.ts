export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL: string;
  coverPhotoURL?: string;
  bio?: string;
  location?: string;
  website?: string;
  followersCount: number;
  followingCount: number;
  followers: string[]; // uids
  following: string[]; // uids
  blockedUsers: string[]; // uids
  online: boolean;
  lastSeen?: any;
  createdAt: any;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  authorPhoto: string;
  content: string;
  mediaType: 'image' | 'video' | 'none';
  mediaUrl?: string;
  likesCount: number;
  likes: string[]; // array of uids
  commentsCount: number;
  sharesCount: number;
  createdAt: any;
  updatedAt?: any;
}

export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorPhoto: string;
  text: string;
  createdAt: any;
}

export interface NotificationItem {
  id: string;
  recipientId: string;
  senderId: string;
  senderName: string;
  senderPhoto: string;
  type: 'like' | 'comment' | 'follow' | 'message';
  postId?: string;
  message: string;
  read: boolean;
  createdAt: any;
}

export interface ChatRoom {
  id: string;
  participants: string[];
  lastMessage?: string;
  lastMessageTime?: any;
  lastSenderId?: string;
  unreadCount?: Record<string, number>;
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  receiverId: string;
  text: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video' | 'none';
  createdAt: any;
  read: boolean;
}

export interface Report {
  id: string;
  reporterId: string;
  targetType: 'post' | 'user';
  targetId: string;
  reason: string;
  details?: string;
  createdAt: any;
}
