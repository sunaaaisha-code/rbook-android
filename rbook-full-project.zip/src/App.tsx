import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LoginView } from './views/LoginView';
import { FeedView } from './views/FeedView';
import { ProfileView } from './views/ProfileView';
import { ChatView } from './views/ChatView';
import { NotificationsView } from './views/NotificationsView';
import { SearchView } from './views/SearchView';
import { SettingsView } from './views/SettingsView';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { RightBar } from './components/RightBar';
import { ApkBuildModal } from './components/ApkBuildModal';

function MainAppContent() {
  const { user, loading, activeView, isApkModalOpen, setIsApkModalOpen } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center space-y-4">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-violet-600 text-white font-extrabold flex items-center justify-center text-2xl shadow-xl animate-bounce">
          R
        </div>
        <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Loading RBook Social...</p>
      </div>
    );
  }

  if (!user) {
    return <LoginView />;
  }

  const renderActiveView = () => {
    switch (activeView) {
      case 'feed':
        return <FeedView />;
      case 'profile':
        return <ProfileView />;
      case 'chat':
        return <ChatView />;
      case 'notifications':
        return <NotificationsView />;
      case 'search':
        return <SearchView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <FeedView />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors">
      
      {/* Navigation Header */}
      <Navbar onToggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)} />

      {/* Main Layout Grid */}
      <div className="max-w-7xl mx-auto px-4 flex">
        
        {/* Left Navigation Sidebar */}
        <Sidebar
          isMobileOpen={mobileMenuOpen}
          onCloseMobile={() => setMobileMenuOpen(false)}
        />

        {/* Center Main View Stream */}
        <main className="flex-1 min-w-0 py-6">
          {renderActiveView()}
        </main>

        {/* Right Sidebar Widgets */}
        <RightBar />

      </div>

      {/* Android APK Download / Build Center Modal */}
      <ApkBuildModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainAppContent />
    </AuthProvider>
  );
}
