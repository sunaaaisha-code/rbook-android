import React, { createContext, useContext, useEffect, useState } from 'react';
import { User as FirebaseUser } from 'firebase/auth';
import { 
  auth, 
  onAuthStateChanged, 
  signOut 
} from '../lib/firebase';
import { UserProfile, NotificationItem } from '../types';
import { 
  getUserProfile, 
  createUserProfile, 
  updateUserOnlineStatus, 
  subscribeToNotifications 
} from '../services/db';

interface AuthContextType {
  firebaseUser: FirebaseUser | null;
  user: UserProfile | null;
  loading: boolean;
  activeView: 'feed' | 'profile' | 'chat' | 'notifications' | 'search' | 'settings';
  selectedUserId: string | null;
  activeChatUserId: string | null;
  notifications: NotificationItem[];
  unreadNotifCount: number;
  isApkModalOpen: boolean;
  setIsApkModalOpen: (open: boolean) => void;
  setActiveView: (view: 'feed' | 'profile' | 'chat' | 'notifications' | 'search' | 'settings', userId?: string) => void;
  openChatWithUser: (userId: string) => void;
  refreshUserProfile: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeView, setActiveViewInternal] = useState<'feed' | 'profile' | 'chat' | 'notifications' | 'search' | 'settings'>('feed');
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [activeChatUserId, setActiveChatUserId] = useState<string | null>(null);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [isApkModalOpen, setIsApkModalOpen] = useState<boolean>(false);

  // Subscribe to Firebase auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fUser) => {
      setFirebaseUser(fUser);
      if (fUser) {
        let profile = await getUserProfile(fUser.uid);
        if (!profile) {
          profile = await createUserProfile({
            uid: fUser.uid,
            email: fUser.email || `${fUser.uid}@rbook.com`,
            displayName: fUser.displayName || fUser.email?.split('@')[0] || 'RBook User',
            photoURL: fUser.photoURL || undefined
          });
        }
        setUser(profile);
        updateUserOnlineStatus(fUser.uid, true);
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Update online status on window unload
  useEffect(() => {
    const handleUnload = () => {
      if (user?.uid) {
        updateUserOnlineStatus(user.uid, false);
      }
    };
    window.addEventListener('beforeunload', handleUnload);
    return () => window.removeEventListener('beforeunload', handleUnload);
  }, [user]);

  // Subscribe to real-time notifications
  useEffect(() => {
    if (!user?.uid) {
      setNotifications([]);
      return;
    }
    const unsub = subscribeToNotifications(user.uid, (notifs) => {
      setNotifications(notifs);
    });
    return () => unsub();
  }, [user?.uid]);

  const refreshUserProfile = async () => {
    if (user?.uid) {
      const updated = await getUserProfile(user.uid);
      if (updated) setUser(updated);
    }
  };

  const setActiveView = (view: 'feed' | 'profile' | 'chat' | 'notifications' | 'search' | 'settings', userId?: string) => {
    setActiveViewInternal(view);
    if (view === 'profile') {
      setSelectedUserId(userId || user?.uid || null);
    } else {
      setSelectedUserId(null);
    }
  };

  const openChatWithUser = (userId: string) => {
    setActiveChatUserId(userId);
    setActiveViewInternal('chat');
  };

  const logout = async () => {
    if (user?.uid) {
      await updateUserOnlineStatus(user.uid, false);
    }
    await signOut(auth);
    setUser(null);
    setFirebaseUser(null);
    setActiveViewInternal('feed');
  };

  const unreadNotifCount = notifications.filter((n) => !n.read).length;

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        user,
        loading,
        activeView,
        selectedUserId,
        activeChatUserId,
        notifications,
        unreadNotifCount,
        isApkModalOpen,
        setIsApkModalOpen,
        setActiveView,
        openChatWithUser,
        refreshUserProfile,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
