import React, { useState, useEffect } from 'react';
import { Search, UserPlus, UserCheck, MessageSquare, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { UserProfile } from '../types';
import { searchUsers, toggleFollowUser } from '../services/db';

export const SearchView: React.FC = () => {
  const { user, setActiveView, openChatWithUser, refreshUserProfile } = useAuth();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let isMounted = true;
    const term = query.trim();
    if (!term) {
      // show default suggested users
      searchUsers('a').then((users) => {
        if (isMounted) setResults(users.filter((u) => u.uid !== user?.uid));
      });
      return;
    }

    setLoading(true);
    searchUsers(term).then((users) => {
      if (isMounted) {
        setResults(users.filter((u) => u.uid !== user?.uid));
        setLoading(false);
      }
    });

    return () => { isMounted = false; };
  }, [query, user]);

  const handleToggleFollow = async (targetUser: UserProfile) => {
    if (!user) return;
    const isFollowing = user.following?.includes(targetUser.uid) || false;
    await toggleFollowUser(user.uid, targetUser.uid, isFollowing, user.displayName, user.photoURL);
    await refreshUserProfile();
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      
      {/* Search Header Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm space-y-4">
        <div>
          <h1 className="text-lg font-black text-slate-900 dark:text-white flex items-center">
            <Search className="w-5 h-5 text-blue-600 mr-2" />
            Find & Discover Users
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Search RBook members by name, email, or bio to connect and follow.
          </p>
        </div>

        <div className="relative">
          <Search className="absolute left-4 top-3.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name, email, or location..."
            className="w-full pl-11 pr-4 py-3 bg-slate-100 dark:bg-slate-800 border border-transparent rounded-2xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500 transition-all"
          />
        </div>
      </div>

      {/* Results List */}
      <div className="space-y-3">
        {loading ? (
          <div className="py-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
            <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
            <p className="text-xs text-slate-500 font-semibold">Searching users...</p>
          </div>
        ) : results.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
            <p className="text-xs text-slate-500 font-semibold">No users matching "{query}"</p>
          </div>
        ) : (
          results.map((u) => {
            const isFollowing = user?.following?.includes(u.uid) || false;

            return (
              <div
                key={u.uid}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-3xl shadow-sm flex items-center justify-between hover:border-slate-300 dark:hover:border-slate-700 transition-all"
              >
                <div
                  onClick={() => setActiveView('profile', u.uid)}
                  className="flex items-center space-x-3.5 cursor-pointer overflow-hidden flex-1 mr-3"
                >
                  <div className="relative shrink-0">
                    <img
                      src={u.photoURL}
                      alt={u.displayName}
                      className="w-12 h-12 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                    />
                    {u.online && (
                      <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white dark:border-slate-900 rounded-full" />
                    )}
                  </div>
                  <div className="overflow-hidden text-xs">
                    <h3 className="font-bold text-slate-900 dark:text-white hover:underline truncate">
                      {u.displayName}
                    </h3>
                    <p className="text-slate-500 dark:text-slate-400 truncate">@{u.email.split('@')[0]}</p>
                    <p className="text-slate-600 dark:text-slate-300 line-clamp-1 mt-0.5 text-[11px]">
                      {u.bio || 'RBook member'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2 shrink-0">
                  <button
                    onClick={() => openChatWithUser(u.uid)}
                    className="p-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-2xl transition-colors"
                    title="Direct Message"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => handleToggleFollow(u)}
                    className={`px-4 py-2 rounded-2xl text-xs font-bold flex items-center shadow-sm transition-all ${
                      isFollowing
                        ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200'
                        : 'bg-blue-600 hover:bg-blue-700 text-white'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <UserCheck className="w-4 h-4 mr-1 text-emerald-500" />
                        Following
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4 mr-1" />
                        Follow
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

    </div>
  );
};
