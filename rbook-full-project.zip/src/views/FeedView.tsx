import React, { useState, useEffect } from 'react';
import { Image, Video, Sparkles, Plus, Layers } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Post } from '../types';
import { subscribeToPosts, DEFAULT_AVATARS } from '../services/db';
import { PostCard } from '../components/PostCard';
import { CreatePostModal } from '../components/CreatePostModal';

export const FeedView: React.FC = () => {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  useEffect(() => {
    setLoading(true);
    const unsub = subscribeToPosts((updatedPosts) => {
      setPosts(updatedPosts);
      setLoading(false);
    }, user?.blockedUsers || []);

    return () => unsub();
  }, [user?.blockedUsers]);

  // Sample stories data for social aesthetic
  const sampleStories = [
    { id: '1', name: 'Your Story', avatar: user?.photoURL || DEFAULT_AVATARS[0], isAdd: true },
    { id: '2', name: 'Alex M.', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80', active: true },
    { id: '3', name: 'Sarah J.', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80', active: true },
    { id: '4', name: 'RBook Hub', avatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80', active: true }
  ];

  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      
      {/* Stories Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm flex items-center space-x-3 overflow-x-auto scrollbar-none">
        {sampleStories.map((s) => (
          <div
            key={s.id}
            onClick={() => s.isAdd && setIsCreateOpen(true)}
            className="flex flex-col items-center space-y-1 shrink-0 cursor-pointer group"
          >
            <div className={`relative w-14 h-14 rounded-full p-0.5 transition-transform group-hover:scale-105 ${
              s.isAdd
                ? 'border-2 border-dashed border-slate-300 dark:border-slate-700'
                : 'bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-600'
            }`}>
              <img
                src={s.avatar}
                alt={s.name}
                className="w-full h-full rounded-full object-cover border-2 border-white dark:border-slate-900"
              />
              {s.isAdd && (
                <div className="absolute bottom-0 right-0 w-5 h-5 bg-blue-600 text-white rounded-full flex items-center justify-center border-2 border-white dark:border-slate-900 shadow">
                  <Plus className="w-3.5 h-3.5" />
                </div>
              )}
            </div>
            <span className="text-[10px] font-bold text-slate-700 dark:text-slate-300 truncate max-w-[60px]">
              {s.name}
            </span>
          </div>
        ))}
      </div>

      {/* Create Post Widget Trigger */}
      {user && (
        <div 
          onClick={() => setIsCreateOpen(true)}
          className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm cursor-pointer hover:border-blue-400 dark:hover:border-blue-600 transition-all group"
        >
          <div className="flex items-center space-x-3">
            <img
              src={user.photoURL}
              alt={user.displayName}
              className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700"
            />
            <div className="flex-1 px-4 py-2.5 bg-slate-100 dark:bg-slate-800 rounded-2xl text-xs text-slate-400 group-hover:bg-slate-200/70 dark:group-hover:bg-slate-700/70 transition-colors">
              What's on your mind, {user.displayName.split(' ')[0]}?
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-around text-xs font-semibold text-slate-600 dark:text-slate-300">
            <div className="flex items-center space-x-1.5 hover:text-emerald-500 transition-colors">
              <Image className="w-4 h-4 text-emerald-500" />
              <span>Photo</span>
            </div>
            <div className="flex items-center space-x-1.5 hover:text-indigo-500 transition-colors">
              <Video className="w-4 h-4 text-indigo-500" />
              <span>Video</span>
            </div>
            <div className="flex items-center space-x-1.5 hover:text-amber-500 transition-colors">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Post</span>
            </div>
          </div>
        </div>
      )}

      {/* Posts Stream */}
      <div className="space-y-4">
        {loading ? (
          <div className="py-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
            <div className="w-8 h-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
            <p className="text-xs text-slate-500 font-semibold">Loading RBook feed...</p>
          </div>
        ) : posts.length === 0 ? (
          <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-3">
            <Layers className="w-10 h-10 text-slate-400 mx-auto" />
            <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">No Posts in Feed Yet</h3>
            <p className="text-xs text-slate-500">Be the first to create a post on RBook!</p>
            <button
              onClick={() => setIsCreateOpen(true)}
              className="px-5 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20"
            >
              Create First Post
            </button>
          </div>
        ) : (
          posts.map((p) => <PostCard key={p.id} post={p} />)
        )}
      </div>

      {/* Create Post Modal */}
      <CreatePostModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
      />

    </div>
  );
};
