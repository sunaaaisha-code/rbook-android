import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  Image, 
  Video, 
  Search, 
  User, 
  MessageSquare, 
  CheckCheck, 
  Sparkles,
  PhoneCall
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ChatRoom, Message, UserProfile } from '../types';
import { 
  subscribeToUserChats, 
  subscribeToChatMessages, 
  sendChatMessage, 
  getOrCreateChatRoom, 
  getUserProfile,
  searchUsers
} from '../services/db';

export const ChatView: React.FC = () => {
  const { user, activeChatUserId, openChatWithUser, setActiveView } = useAuth();
  
  const [chats, setChats] = useState<ChatRoom[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [activePartner, setActivePartner] = useState<UserProfile | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [messageText, setMessageText] = useState('');
  const [sending, setSending] = useState(false);

  // Search user to start new chat
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<UserProfile[]>([]);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Subscribe to user's chat rooms
  useEffect(() => {
    if (!user) return;
    const unsub = subscribeToUserChats(user.uid, (rooms) => {
      setChats(rooms);
    });
    return () => unsub();
  }, [user]);

  // Handle activeChatUserId param
  useEffect(() => {
    if (user && activeChatUserId) {
      getOrCreateChatRoom(user.uid, activeChatUserId).then((roomId) => {
        setActiveChatId(roomId);
      });
      getUserProfile(activeChatUserId).then((p) => {
        if (p) setActivePartner(p);
      });
    }
  }, [user, activeChatUserId]);

  // Subscribe to messages of active room
  useEffect(() => {
    if (!activeChatId) return;
    const unsub = subscribeToChatMessages(activeChatId, (msgs) => {
      setMessages(msgs);
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    });
    return () => unsub();
  }, [activeChatId]);

  // Handle room selection
  const handleSelectRoom = async (room: ChatRoom) => {
    setActiveChatId(room.id);
    const partnerId = room.participants.find((id) => id !== user?.uid);
    if (partnerId) {
      const partner = await getUserProfile(partnerId);
      setActivePartner(partner);
    }
  };

  // Handle user search in chat
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }
    searchUsers(searchQuery).then((res) => {
      setSearchResults(res.filter((u) => u.uid !== user?.uid));
    });
  }, [searchQuery, user]);

  const handleStartChatWithUser = async (targetUser: UserProfile) => {
    if (!user) return;
    const roomId = await getOrCreateChatRoom(user.uid, targetUser.uid);
    setActiveChatId(roomId);
    setActivePartner(targetUser);
    setSearchQuery('');
    setSearchResults([]);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || !user || !activePartner || !activeChatId) return;

    setSending(true);
    const textToSend = messageText.trim();
    setMessageText('');

    try {
      await sendChatMessage({
        chatId: activeChatId,
        senderId: user.uid,
        receiverId: activePartner.uid,
        text: textToSend,
        senderName: user.displayName,
        senderPhoto: user.photoURL
      });
      setSending(false);
    } catch (e) {
      setSending(false);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-sm overflow-hidden h-[calc(100vh-7rem)] flex flex-col md:flex-row">
      
      {/* Left Sidebar: Conversations List */}
      <div className="w-full md:w-80 border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-800 flex flex-col shrink-0">
        
        {/* Chat Search Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 space-y-3">
          <h2 className="text-base font-black text-slate-900 dark:text-white flex items-center justify-between">
            <span>Direct Messages</span>
            <span className="text-xs bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 font-bold px-2.5 py-0.5 rounded-full">
              Live Chat
            </span>
          </h2>

          <div className="relative">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search user to chat..."
              className="w-full pl-9 pr-3 py-2 bg-slate-100 dark:bg-slate-800 border border-transparent rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        {/* User Search Results */}
        {searchResults.length > 0 ? (
          <div className="p-2 space-y-1 overflow-y-auto max-h-48 border-b border-slate-200 dark:border-slate-800 bg-blue-50/50 dark:bg-blue-950/20">
            <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 px-3 uppercase tracking-wider">
              Search Results
            </span>
            {searchResults.map((u) => (
              <div
                key={u.uid}
                onClick={() => handleStartChatWithUser(u)}
                className="flex items-center space-x-3 p-2 hover:bg-blue-100/60 dark:hover:bg-blue-900/40 rounded-xl cursor-pointer"
              >
                <img src={u.photoURL} alt="" className="w-8 h-8 rounded-full object-cover" />
                <div className="truncate text-xs">
                  <p className="font-bold text-slate-900 dark:text-white truncate">{u.displayName}</p>
                  <p className="text-slate-500 text-[10px] truncate">{u.email}</p>
                </div>
              </div>
            ))}
          </div>
        ) : null}

        {/* Chat Rooms Stream List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {chats.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-400">
              No conversations yet. Search a user above to start chatting!
            </div>
          ) : (
            chats.map((room) => {
              const isActive = activeChatId === room.id;

              return (
                <div
                  key={room.id}
                  onClick={() => handleSelectRoom(room)}
                  className={`p-3 rounded-2xl cursor-pointer transition-all flex items-center space-x-3 ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800/80 text-slate-800 dark:text-slate-200'
                  }`}
                >
                  <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center shrink-0">
                    <User className="w-5 h-5 text-slate-400" />
                  </div>
                  <div className="flex-1 overflow-hidden text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold truncate">Chat Conversation</span>
                      {room.lastMessageTime && (
                        <span className="text-[10px] opacity-70">
                          {new Date(room.lastMessageTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      )}
                    </div>
                    <p className="opacity-80 truncate text-[11px] mt-0.5">
                      {room.lastMessage || 'Start conversation...'}
                    </p>
                  </div>
                </div>
              );
            })
          )}
        </div>

      </div>

      {/* Right Area: Active Messaging Screen */}
      <div className="flex-1 flex flex-col bg-slate-50/50 dark:bg-slate-900/50">
        
        {activePartner ? (
          <>
            {/* Active Partner Header */}
            <div className="p-4 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
              <div 
                onClick={() => setActiveView('profile', activePartner.uid)}
                className="flex items-center space-x-3 cursor-pointer group"
              >
                <div className="relative">
                  <img
                    src={activePartner.photoURL}
                    alt={activePartner.displayName}
                    className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                  />
                  {activePartner.online && (
                    <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white dark:border-slate-900 rounded-full" />
                  )}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-blue-600 transition-colors">
                    {activePartner.displayName}
                  </h3>
                  <p className="text-[11px] text-slate-400 font-semibold">
                    {activePartner.online ? 'Online now' : 'Offline'}
                  </p>
                </div>
              </div>
            </div>

            {/* Messages Feed Area */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3">
              {messages.length === 0 ? (
                <div className="py-12 text-center text-xs text-slate-400">
                  This is the beginning of your 1-to-1 conversation with {activePartner.displayName}.
                </div>
              ) : (
                messages.map((m) => {
                  const isMe = m.senderId === user?.uid;

                  return (
                    <div
                      key={m.id}
                      className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                    >
                      <div
                        className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-xs font-medium space-y-1 ${
                          isMe
                            ? 'bg-blue-600 text-white rounded-br-none shadow-md shadow-blue-500/15'
                            : 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-bl-none border border-slate-200 dark:border-slate-700 shadow-sm'
                        }`}
                      >
                        <p className="whitespace-pre-wrap leading-relaxed">{m.text}</p>
                        <span className={`text-[9px] block text-right opacity-70 ${isMe ? 'text-blue-100' : 'text-slate-400'}`}>
                          {m.createdAt ? new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input Box */}
            <div className="p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 shrink-0">
              <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
                <input
                  type="text"
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  placeholder={`Message ${activePartner.displayName.split(' ')[0]}...`}
                  className="flex-1 px-4 py-3 bg-slate-100 dark:bg-slate-800 border border-transparent rounded-2xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
                />
                <button
                  type="submit"
                  disabled={sending || !messageText.trim()}
                  className="px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl text-xs font-bold transition-all shadow-md shadow-blue-500/20 disabled:opacity-50 flex items-center space-x-1"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-3 text-slate-400">
            <MessageSquare className="w-12 h-12 text-slate-300 dark:text-slate-700" />
            <h3 className="text-base font-bold text-slate-700 dark:text-slate-300">Your Messages</h3>
            <p className="text-xs max-w-sm">Select a conversation from the left or search a user to start direct chatting.</p>
          </div>
        )}

      </div>

    </div>
  );
};
