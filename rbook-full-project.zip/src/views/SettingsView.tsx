import React, { useState, useEffect } from 'react';
import { 
  Settings, 
  ShieldAlert, 
  Smartphone, 
  LogOut, 
  UserX, 
  CheckCircle2, 
  Sparkles,
  Lock
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { UserProfile } from '../types';
import { getUserProfile, unblockUser } from '../services/db';

export const SettingsView: React.FC = () => {
  const { user, setIsApkModalOpen, logout, refreshUserProfile } = useAuth();
  const [blockedProfiles, setBlockedProfiles] = useState<UserProfile[]>([]);
  const [loadingBlocked, setLoadingBlocked] = useState(false);

  useEffect(() => {
    let isMounted = true;
    if (user?.blockedUsers && user.blockedUsers.length > 0) {
      setLoadingBlocked(true);
      Promise.all(user.blockedUsers.map((uid) => getUserProfile(uid))).then((profiles) => {
        if (isMounted) {
          setBlockedProfiles(profiles.filter(Boolean) as UserProfile[]);
          setLoadingBlocked(false);
        }
      });
    } else {
      setBlockedProfiles([]);
    }
    return () => { isMounted = false; };
  }, [user?.blockedUsers]);

  const handleUnblock = async (targetUid: string) => {
    if (!user) return;
    await unblockUser(user.uid, targetUid);
    await refreshUserProfile();
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm flex items-center space-x-3">
        <div className="p-3 bg-indigo-50 dark:bg-indigo-950/60 rounded-2xl text-indigo-600 dark:text-indigo-400">
          <Settings className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-lg font-black text-slate-900 dark:text-white">Settings & Privacy</h1>
          <p className="text-xs text-slate-500">Manage account security, blocked users, and mobile app exports.</p>
        </div>
      </div>

      {/* Account Info */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
        <h2 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center">
          <Lock className="w-4 h-4 text-blue-600 mr-2" />
          Account Details
        </h2>

        {user && (
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/60 space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-500 font-semibold">Full Name:</span>
              <span className="font-bold text-slate-900 dark:text-white">{user.displayName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500 font-semibold">Email:</span>
              <span className="font-bold text-slate-900 dark:text-white">{user.email}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500 font-semibold">Firebase UID:</span>
              <span className="font-mono text-[10px] text-slate-400">{user.uid}</span>
            </div>
          </div>
        )}
      </div>

      {/* Android APK Callout */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white rounded-3xl p-6 shadow-lg shadow-emerald-500/15 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="space-y-1">
          <h3 className="text-base font-extrabold flex items-center">
            <Smartphone className="w-5 h-5 mr-2" />
            Download & Build Android APK
          </h3>
          <p className="text-xs text-emerald-100 max-w-md">
            Generate mobile package configuration or view Capacitor CLI build commands for native Android compilation.
          </p>
        </div>
        <button
          onClick={() => setIsApkModalOpen(true)}
          className="px-5 py-2.5 bg-white hover:bg-emerald-50 text-emerald-800 font-extrabold text-xs rounded-2xl shadow-md transition-all shrink-0"
        >
          Build Android APK
        </button>
      </div>

      {/* Blocked Users Section */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
        <h2 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center">
          <ShieldAlert className="w-4 h-4 text-rose-600 mr-2" />
          Blocked Accounts ({blockedProfiles.length})
        </h2>

        {loadingBlocked ? (
          <div className="py-4 text-center">
            <div className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
          </div>
        ) : blockedProfiles.length === 0 ? (
          <p className="text-xs text-slate-400 py-2">You haven't blocked any accounts.</p>
        ) : (
          <div className="space-y-2">
            {blockedProfiles.map((p) => (
              <div key={p.uid} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700/60">
                <div className="flex items-center space-x-3">
                  <img src={p.photoURL} alt="" className="w-9 h-9 rounded-full object-cover" />
                  <div className="text-xs">
                    <p className="font-bold text-slate-900 dark:text-white">{p.displayName}</p>
                    <p className="text-[10px] text-slate-400">{p.email}</p>
                  </div>
                </div>

                <button
                  onClick={() => handleUnblock(p.uid)}
                  className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 rounded-xl text-xs font-semibold transition-colors flex items-center space-x-1"
                >
                  <UserX className="w-3.5 h-3.5" />
                  <span>Unblock</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Logout */}
      <div className="pt-2">
        <button
          onClick={logout}
          className="w-full py-3 bg-red-50 hover:bg-red-100 dark:bg-red-950/30 dark:hover:bg-red-950/50 text-red-600 dark:text-red-400 font-bold text-xs rounded-2xl border border-red-200 dark:border-red-900/60 transition-colors flex items-center justify-center space-x-2"
        >
          <LogOut className="w-4 h-4" />
          <span>Sign Out of RBook</span>
        </button>
      </div>

    </div>
  );
};
