import React, { useState, useEffect } from 'react';
import { 
  UserCheck, 
  UserPlus, 
  MessageSquare, 
  Edit3, 
  ShieldAlert, 
  Flag, 
  MapPin, 
  Globe, 
  Calendar, 
  Grid, 
  Heart, 
  Bookmark,
  Users
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { UserProfile, Post } from '../types';
import { 
  getUserProfile, 
  toggleFollowUser, 
  blockUser, 
  unblockUser, 
  subscribeToPosts 
} from '../services/db';
import { PostCard } from '../components/PostCard';
import { EditProfileModal } from '../components/EditProfileModal';
import { FollowersModal } from '../components/FollowersModal';
import { ReportModal } from '../components/ReportModal';

export const ProfileView: React.FC = () => {
  const { user: currentUser, selectedUserId, openChatWithUser, refreshUserProfile } = useAuth();
  
  const targetUid = selectedUserId || currentUser?.uid;
  const isSelf = currentUser?.uid === targetUid;

  const [profile, setProfile] = useState<UserProfile | null>(isSelf ? currentUser : null);
  const [loading, setLoading] = useState(!isSelf);
  const [userPosts, setUserPosts] = useState<Post[]>([]);
  const [activeTab, setActiveTab] = useState<'posts' | 'liked' | 'saved'>('posts');

  const [showEditModal, setShowEditModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [followersModalState, setFollowersModalState] = useState<{
    isOpen: boolean;
    title: 'Followers' | 'Following';
    ids: string[];
  }>({ isOpen: false, title: 'Followers', ids: [] });

  // Fetch target profile
  useEffect(() => {
    let isMounted = true;
    if (isSelf && currentUser) {
      setProfile(currentUser);
      setLoading(false);
    } else if (targetUid) {
      setLoading(true);
      getUserProfile(targetUid).then((p) => {
        if (isMounted) {
          setProfile(p);
          setLoading(false);
        }
      });
    }
    return () => { isMounted = false; };
  }, [targetUid, isSelf, currentUser]);

  // Subscribe to all posts and filter for profile tabs
  useEffect(() => {
    if (!targetUid) return;
    const unsub = subscribeToPosts((allPosts) => {
      setUserPosts(allPosts);
    });
    return () => unsub();
  }, [targetUid]);

  if (loading) {
    return (
      <div className="py-20 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
        <div className="w-8 h-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
        <p className="text-xs text-slate-500 font-semibold">Loading profile...</p>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
        <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">User Not Found</h3>
        <p className="text-xs text-slate-500 mt-1">This account does not exist or has been removed.</p>
      </div>
    );
  }

  const isFollowing = currentUser?.following?.includes(profile.uid) || false;
  const isBlocked = currentUser?.blockedUsers?.includes(profile.uid) || false;

  const handleToggleFollow = async () => {
    if (!currentUser) return;
    await toggleFollowUser(currentUser.uid, profile.uid, isFollowing, currentUser.displayName, currentUser.photoURL);
    await refreshUserProfile();
    const updated = await getUserProfile(profile.uid);
    if (updated) setProfile(updated);
  };

  const handleToggleBlock = async () => {
    if (!currentUser) return;
    if (isBlocked) {
      await unblockUser(currentUser.uid, profile.uid);
    } else {
      if (window.confirm(`Block @${profile.displayName}? You will no longer see their posts or messages.`)) {
        await blockUser(currentUser.uid, profile.uid);
      }
    }
    await refreshUserProfile();
  };

  // Tab Filtering
  const filteredPosts = userPosts.filter((p) => {
    if (activeTab === 'posts') return p.authorId === profile.uid;
    if (activeTab === 'liked') return p.likes?.includes(profile.uid);
    if (activeTab === 'saved') return p.authorId === profile.uid;
    return true;
  });

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      
      {/* Profile Header Card */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        
        {/* Cover Photo */}
        <div className="h-44 sm:h-52 bg-slate-200 dark:bg-slate-800 relative">
          <img
            src={profile.coverPhotoURL || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&auto=format&fit=crop&q=80'}
            alt="Cover"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Avatar & Action Buttons Bar */}
        <div className="px-6 pb-6 relative">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between -mt-16 sm:-mt-20 mb-4 gap-4">
            
            {/* Avatar */}
            <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-full border-4 border-white dark:border-slate-900 overflow-hidden shadow-xl bg-slate-200 shrink-0">
              <img src={profile.photoURL} alt={profile.displayName} className="w-full h-full object-cover" />
              {profile.online && (
                <span className="absolute bottom-1 right-1 w-4 h-4 bg-emerald-500 border-2 border-white dark:border-slate-900 rounded-full" title="Online now" />
              )}
            </div>

            {/* Profile Action Buttons */}
            <div className="flex items-center space-x-2">
              {isSelf ? (
                <button
                  onClick={() => setShowEditModal(true)}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 font-bold text-xs rounded-2xl transition-all flex items-center shadow-sm"
                >
                  <Edit3 className="w-4 h-4 mr-1.5 text-blue-600" />
                  Edit Profile
                </button>
              ) : (
                <>
                  <button
                    onClick={() => openChatWithUser(profile.uid)}
                    className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 font-bold text-xs rounded-2xl transition-all flex items-center"
                  >
                    <MessageSquare className="w-4 h-4 mr-1.5 text-indigo-500" />
                    Message
                  </button>

                  <button
                    onClick={handleToggleFollow}
                    className={`px-5 py-2.5 rounded-2xl font-bold text-xs flex items-center shadow-md transition-all ${
                      isFollowing
                        ? 'bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200'
                        : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/20'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <UserCheck className="w-4 h-4 mr-1.5 text-emerald-500" />
                        Following
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-4 h-4 mr-1.5" />
                        Follow
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleToggleBlock}
                    className={`p-2.5 rounded-2xl border transition-colors ${
                      isBlocked
                        ? 'bg-red-600 text-white border-red-600'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-red-500 border-slate-200 dark:border-slate-700'
                    }`}
                    title={isBlocked ? 'Unblock User' : 'Block User'}
                  >
                    <ShieldAlert className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => setShowReportModal(true)}
                    className="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-amber-500 border border-slate-200 dark:border-slate-700 transition-colors"
                    title="Report User"
                  >
                    <Flag className="w-4 h-4" />
                  </button>
                </>
              )}
            </div>

          </div>

          {/* User Meta & Bio */}
          <div className="space-y-3">
            <div>
              <h1 className="text-xl font-black text-slate-900 dark:text-white flex items-center">
                {profile.displayName}
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">@{profile.email.split('@')[0]}</p>
            </div>

            {profile.bio && (
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed max-w-xl">
                {profile.bio}
              </p>
            )}

            <div className="flex flex-wrap items-center gap-4 text-xs font-semibold text-slate-500 dark:text-slate-400 pt-1">
              {profile.location && (
                <div className="flex items-center space-x-1">
                  <MapPin className="w-3.5 h-3.5 text-rose-500" />
                  <span>{profile.location}</span>
                </div>
              )}
              {profile.website && (
                <a 
                  href={profile.website.startsWith('http') ? profile.website : `https://${profile.website}`} 
                  target="_blank" 
                  rel="noreferrer"
                  className="flex items-center space-x-1 text-blue-600 hover:underline"
                >
                  <Globe className="w-3.5 h-3.5" />
                  <span>{profile.website.replace(/^https?:\/\//, '')}</span>
                </a>
              )}
              <div className="flex items-center space-x-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>Joined RBook</span>
              </div>
            </div>

            {/* Followers & Following Counters */}
            <div className="flex items-center space-x-6 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setFollowersModalState({ isOpen: true, title: 'Followers', ids: profile.followers || [] })}
                className="hover:underline flex items-center space-x-1"
              >
                <span className="text-sm font-black text-slate-900 dark:text-white">{profile.followersCount || 0}</span>
                <span className="text-xs text-slate-500 font-semibold">Followers</span>
              </button>

              <button
                onClick={() => setFollowersModalState({ isOpen: true, title: 'Following', ids: profile.following || [] })}
                className="hover:underline flex items-center space-x-1"
              >
                <span className="text-sm font-black text-slate-900 dark:text-white">{profile.followingCount || 0}</span>
                <span className="text-xs text-slate-500 font-semibold">Following</span>
              </button>
            </div>

          </div>

        </div>

      </div>

      {/* Tabs Selector */}
      <div className="flex bg-white dark:bg-slate-900 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <button
          onClick={() => setActiveTab('posts')}
          className={`flex-1 py-2.5 text-xs font-extrabold rounded-xl transition-all flex items-center justify-center space-x-2 ${
            activeTab === 'posts' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Grid className="w-4 h-4" />
          <span>Posts</span>
        </button>

        <button
          onClick={() => setActiveTab('liked')}
          className={`flex-1 py-2.5 text-xs font-extrabold rounded-xl transition-all flex items-center justify-center space-x-2 ${
            activeTab === 'liked' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>Liked Posts</span>
        </button>

        <button
          onClick={() => setActiveTab('saved')}
          className={`flex-1 py-2.5 text-xs font-extrabold rounded-xl transition-all flex items-center justify-center space-x-2 ${
            activeTab === 'saved' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Bookmark className="w-4 h-4" />
          <span>Saved</span>
        </button>
      </div>

      {/* Tab Posts Stream */}
      <div className="space-y-4">
        {filteredPosts.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-2">
            <p className="text-xs text-slate-500 font-semibold">No posts found in this tab.</p>
          </div>
        ) : (
          filteredPosts.map((p) => <PostCard key={p.id} post={p} />)
        )}
      </div>

      {/* Modals */}
      <EditProfileModal
        isOpen={showEditModal}
        onClose={() => setShowEditModal(false)}
      />

      <FollowersModal
        isOpen={followersModalState.isOpen}
        onClose={() => setFollowersModalState({ ...followersModalState, isOpen: false })}
        title={followersModalState.title}
        userIds={followersModalState.ids}
      />

      <ReportModal
        isOpen={showReportModal}
        onClose={() => setShowReportModal(false)}
        targetType="user"
        targetId={profile.uid}
        targetName={profile.displayName}
      />

    </div>
  );
};
