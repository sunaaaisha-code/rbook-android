import React, { useState } from 'react';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  sendPasswordResetEmail, 
  signInWithPopup, 
  googleProvider,
  updateProfile,
  auth
} from '../lib/firebase';
import { createUserProfile, DEFAULT_AVATARS } from '../services/db';
import { Lock, Mail, User, Image, Sparkles, AlertCircle, CheckCircle, ArrowRight, Camera } from 'lucide-react';

export const LoginView: React.FC = () => {
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>('login');
  
  // Form State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [photoURL, setPhotoURL] = useState(DEFAULT_AVATARS[0]);
  
  // Status State
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [resetSent, setResetSent] = useState(false);

  const handleAvatarFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => setPhotoURL(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (mode === 'login') {
        await signInWithEmailAndPassword(auth, email.trim(), password);
      } else if (mode === 'signup') {
        if (!displayName.trim()) {
          setError('Please provide your name.');
          setLoading(false);
          return;
        }
        const userCred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        await updateProfile(userCred.user, {
          displayName: displayName.trim(),
          photoURL
        });
        await createUserProfile({
          uid: userCred.user.uid,
          email: email.trim(),
          displayName: displayName.trim(),
          photoURL
        });
      } else if (mode === 'forgot') {
        if (!email.trim()) {
          setError('Please enter your email address.');
          setLoading(false);
          return;
        }
        await sendPasswordResetEmail(auth, email.trim());
        setResetSent(true);
      }
    } catch (err: any) {
      console.error('Auth error:', err);
      let msg = err.message || 'Authentication failed. Please try again.';
      if (err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        msg = 'Invalid email or password.';
      } else if (err.code === 'auth/email-already-in-use') {
        msg = 'This email is already registered. Please sign in.';
      } else if (err.code === 'auth/weak-password') {
        msg = 'Password should be at least 6 characters.';
      }
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setError('');
    setLoading(true);
    try {
      const res = await signInWithPopup(auth, googleProvider);
      if (res.user) {
        await createUserProfile({
          uid: res.user.uid,
          email: res.user.email || '',
          displayName: res.user.displayName || 'RBook Member',
          photoURL: res.user.photoURL || DEFAULT_AVATARS[0]
        });
      }
    } catch (err: any) {
      setError('Google sign-in was cancelled or unavailable.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4 relative overflow-hidden font-sans">
      
      {/* Dynamic Background Glow Decor */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-4xl bg-slate-900/90 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden grid grid-cols-1 md:grid-cols-2 relative z-10">
        
        {/* Left Column: Branding Showcase */}
        <div className="p-8 md:p-12 bg-gradient-to-br from-blue-700 via-indigo-700 to-violet-800 text-white flex flex-col justify-between relative overflow-hidden">
          <div className="space-y-6 relative z-10">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-2xl bg-white text-blue-700 font-extrabold flex items-center justify-center text-2xl shadow-xl">
                R
              </div>
              <span className="text-3xl font-black tracking-tight text-white">RBook</span>
            </div>

            <div className="space-y-3 pt-4">
              <h1 className="text-2xl md:text-3xl font-extrabold leading-tight">
                Connect, Share, and Chat in Real-time.
              </h1>
              <p className="text-blue-100 text-xs md:text-sm leading-relaxed">
                Experience the next generation social hub with live feeds, instant 1-to-1 chat, media posts, and custom user profiles.
              </p>
            </div>
          </div>

          <div className="pt-8 relative z-10">
            <div className="p-4 bg-white/10 backdrop-blur-md rounded-2xl border border-white/15 flex items-center space-x-3">
              <Sparkles className="w-6 h-6 text-yellow-300 shrink-0" />
              <div className="text-xs">
                <p className="font-bold text-white">Firebase Powered</p>
                <p className="text-blue-100 text-[11px]">Real-time authentication & secure database rules</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Authentication Form */}
        <div className="p-8 md:p-10 flex flex-col justify-center space-y-6">
          
          {/* Form Mode Selector */}
          <div className="flex bg-slate-800/80 p-1 rounded-2xl border border-slate-700">
            <button
              onClick={() => { setMode('login'); setError(''); }}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                mode === 'login' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => { setMode('signup'); setError(''); }}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
                mode === 'signup' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              Create Account
            </button>
          </div>

          {/* Form Title */}
          <div>
            <h2 className="text-xl font-bold text-white">
              {mode === 'login' && 'Welcome Back to RBook'}
              {mode === 'signup' && 'Create your RBook Profile'}
              {mode === 'forgot' && 'Reset your Password'}
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              {mode === 'login' && 'Sign in to access your feed, notifications, and direct messages.'}
              {mode === 'signup' && 'Join thousands of users sharing memories everyday.'}
              {mode === 'forgot' && 'Enter your registered email address to receive reset link.'}
            </p>
          </div>

          {/* Error / Success Feedback */}
          {error && (
            <div className="p-3 bg-red-950/50 border border-red-800 text-red-300 rounded-2xl text-xs flex items-center">
              <AlertCircle className="w-4 h-4 mr-2 shrink-0 text-red-400" />
              {error}
            </div>
          )}

          {resetSent && (
            <div className="p-3 bg-emerald-950/50 border border-emerald-800 text-emerald-300 rounded-2xl text-xs flex items-center">
              <CheckCircle className="w-4 h-4 mr-2 shrink-0 text-emerald-400" />
              Password reset link sent to your email!
            </div>
          )}

          <form onSubmit={handleAuthSubmit} className="space-y-4">

            {/* Profile Photo Selection (Sign Up Mode) */}
            {mode === 'signup' && (
              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-300">Choose Profile Photo</label>
                <div className="flex items-center space-x-3">
                  <div className="relative w-12 h-12 rounded-full overflow-hidden border-2 border-blue-500 bg-slate-800 shrink-0">
                    <img src={photoURL} alt="Avatar" className="w-full h-full object-cover" />
                    <label className="absolute inset-0 bg-black/40 hover:bg-black/60 flex items-center justify-center cursor-pointer text-white">
                      <Camera className="w-4 h-4" />
                      <input type="file" accept="image/*" onChange={handleAvatarFile} className="hidden" />
                    </label>
                  </div>
                  
                  <div className="flex space-x-1.5 overflow-x-auto py-1">
                    {DEFAULT_AVATARS.map((av, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setPhotoURL(av)}
                        className={`w-8 h-8 rounded-full overflow-hidden border-2 transition-all ${
                          photoURL === av ? 'border-blue-500 scale-105' : 'border-slate-700 opacity-60'
                        }`}
                      >
                        <img src={av} alt="Avatar" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Name Input (Sign Up Mode) */}
            {mode === 'signup' && (
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Full Name</label>
                <div className="relative">
                  <User className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="e.g. Alex Morgan"
                    required
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            )}

            {/* Email Input */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  required
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Password Input */}
            {mode !== 'forgot' && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-slate-300">Password</label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => setMode('forgot')}
                      className="text-[11px] font-semibold text-blue-400 hover:underline"
                    >
                      Forgot password?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    required
                    minLength={6}
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl transition-all shadow-lg shadow-blue-500/25 flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>
                    {mode === 'login' && 'Sign In to RBook'}
                    {mode === 'signup' && 'Create Account'}
                    {mode === 'forgot' && 'Send Reset Email'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

          </form>

          {/* Social Login Divider */}
          {mode !== 'forgot' && (
            <div className="space-y-4 pt-2">
              <div className="relative flex items-center justify-center">
                <div className="border-t border-slate-800 w-full" />
                <span className="bg-slate-900 px-3 text-[10px] font-bold text-slate-500 uppercase tracking-wider absolute">
                  Or
                </span>
              </div>

              {/* Google Sign In */}
              <button
                type="button"
                onClick={handleGoogleLogin}
                disabled={loading}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs rounded-xl border border-slate-700 flex items-center justify-center space-x-2 transition-colors"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                </svg>
                <span>Continue with Google</span>
              </button>
            </div>
          )}

          {/* Forgot Password Back Button */}
          {mode === 'forgot' && (
            <button
              onClick={() => { setMode('login'); setError(''); setResetSent(false); }}
              className="w-full text-center text-xs font-bold text-slate-400 hover:text-white"
            >
              ← Back to Sign In
            </button>
          )}

        </div>

      </div>
    </div>
  );
};
