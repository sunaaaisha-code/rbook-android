import React from 'react';
import { 
  Bell, 
  Heart, 
  MessageCircle, 
  UserPlus, 
  MessageSquare, 
  Check, 
  Clock 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { markNotificationAsRead, markAllNotificationsAsRead } from '../services/db';

export const NotificationsView: React.FC = () => {
  const { user, notifications, setActiveView, openChatWithUser } = useAuth();

  const handleNotificationClick = async (notif: any) => {
    await markNotificationAsRead(notif.id);
    if (notif.type === 'message') {
      openChatWithUser(notif.senderId);
    } else {
      setActiveView('profile', notif.senderId);
    }
  };

  const handleMarkAllRead = async () => {
    if (user?.uid) {
      await markAllNotificationsAsRead(user.uid);
    }
  };

  const getNotifIcon = (type: string) => {
    switch (type) {
      case 'like':
        return <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />;
      case 'comment':
        return <MessageCircle className="w-4 h-4 text-blue-500" />;
      case 'follow':
        return <UserPlus className="w-4 h-4 text-emerald-500" />;
      case 'message':
        return <MessageSquare className="w-4 h-4 text-indigo-500" />;
      default:
        return <Bell className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      
      {/* Header Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-blue-50 dark:bg-blue-950/60 rounded-2xl text-blue-600 dark:text-blue-400">
            <Bell className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-lg font-black text-slate-900 dark:text-white">Notifications</h1>
            <p className="text-xs text-slate-500">Stay updated with likes, comments, follows & messages.</p>
          </div>
        </div>

        {notifications.some((n) => !n.read) && (
          <button
            onClick={handleMarkAllRead}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition-colors flex items-center space-x-1"
          >
            <Check className="w-4 h-4 text-emerald-500" />
            <span>Mark all as read</span>
          </button>
        )}
      </div>

      {/* Notifications List */}
      <div className="space-y-2">
        {notifications.length === 0 ? (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 space-y-2">
            <p className="text-xs text-slate-500 font-semibold">No notifications yet.</p>
          </div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              onClick={() => handleNotificationClick(n)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                !n.read
                  ? 'bg-blue-50/60 dark:bg-blue-950/30 border-blue-200 dark:border-blue-900/60 shadow-sm'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className="flex items-center space-x-3 overflow-hidden">
                <div className="relative shrink-0">
                  <img
                    src={n.senderPhoto}
                    alt={n.senderName}
                    className="w-11 h-11 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                  />
                  <div className="absolute -bottom-1 -right-1 p-1 bg-white dark:bg-slate-900 rounded-full shadow border border-slate-200 dark:border-slate-700">
                    {getNotifIcon(n.type)}
                  </div>
                </div>

                <div className="overflow-hidden text-xs">
                  <p className="text-slate-900 dark:text-slate-100 font-medium">
                    <span className="font-bold">{n.senderName}</span> {n.message}
                  </p>
                  <p className="text-[10px] text-slate-400 mt-1 flex items-center">
                    <Clock className="w-3 h-3 mr-1" />
                    {n.createdAt ? new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Recently'}
                  </p>
                </div>
              </div>

              {!n.read && (
                <span className="w-2.5 h-2.5 bg-blue-600 rounded-full shrink-0 ml-3" />
              )}
            </div>
          ))
        )}
      </div>

    </div>
  );
};
