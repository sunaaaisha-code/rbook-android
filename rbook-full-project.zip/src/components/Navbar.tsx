import React, { useState } from 'react';
import { 
  Home, 
  MessageSquare, 
  Bell, 
  Search, 
  User, 
  Settings, 
  LogOut, 
  Smartphone, 
  Download,
  BookOpen,
  Sparkles,
  Menu,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  onToggleMobileMenu?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onToggleMobileMenu }) => {
  const { 
    user, 
    activeView, 
    setActiveView, 
    unreadNotifCount, 
    setIsApkModalOpen, 
    logout 
  } = useAuth();

  const [searchQuery, setSearchQuery] = useState('');
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setActiveView('search');
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        
        {/* Left: Brand Logo & Mobile Drawer Toggle */}
        <div className="flex items-center space-x-3">
          <button
            onClick={onToggleMobileMenu}
            className="md:hidden p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl"
          >
            <Menu className="w-6 h-6" />
          </button>

          <div 
            onClick={() => setActiveView('feed')}
            className="flex items-center space-x-2.5 cursor-pointer group select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-violet-600 text-white font-extrabold flex items-center justify-center text-xl shadow-lg shadow-blue-500/25 group-hover:scale-105 transition-transform">
              R
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-black bg-gradient-to-r from-blue-600 via-indigo-600 to-violet-600 bg-clip-text text-transparent tracking-tight">
                RBook
              </span>
              <span className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 -mt-1 tracking-wider uppercase">
                Social Hub
              </span>
            </div>
          </div>
        </div>

        {/* Center: Search Bar */}
        <div className="hidden sm:block flex-1 max-w-md mx-6">
          <form onSubmit={handleSearchSubmit} className="relative">
            <Search className="absolute left-3.5 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search users on RBook..."
              className="w-full pl-10 pr-4 py-2 bg-slate-100 dark:bg-slate-800/80 border border-transparent focus:border-blue-500 rounded-2xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none transition-all"
            />
          </form>
        </div>

        {/* Right Nav Icons */}
        <div className="flex items-center space-x-1 sm:space-x-2">
          
          {/* Feed */}
          <button
            onClick={() => setActiveView('feed')}
            className={`p-2.5 rounded-xl transition-all relative ${
              activeView === 'feed'
                ? 'bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
            title="Home Feed"
          >
            <Home className="w-5 h-5" />
          </button>

          {/* Chat */}
          <button
            onClick={() => setActiveView('chat')}
            className={`p-2.5 rounded-xl transition-all relative ${
              activeView === 'chat'
                ? 'bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
            title="Messages"
          >
            <MessageSquare className="w-5 h-5" />
          </button>

          {/* Notifications */}
          <button
            onClick={() => setActiveView('notifications')}
            className={`p-2.5 rounded-xl transition-all relative ${
              activeView === 'notifications'
                ? 'bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400 font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
            title="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadNotifCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-rose-600 text-white font-bold text-[10px] rounded-full flex items-center justify-center animate-pulse">
                {unreadNotifCount > 9 ? '9+' : unreadNotifCount}
              </span>
            )}
          </button>

          {/* Download APK Action Button */}
          <button
            onClick={() => setIsApkModalOpen(true)}
            className="hidden md:flex items-center space-x-1.5 px-3 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-semibold shadow-sm transition-all"
          >
            <Smartphone className="w-4 h-4" />
            <span>Android APK</span>
          </button>

          {/* User Profile Dropdown */}
          {user && (
            <div className="relative ml-2">
              <button
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="flex items-center space-x-2 p-1 rounded-full border-2 border-transparent hover:border-blue-500 transition-colors"
              >
                <img
                  src={user.photoURL}
                  alt={user.displayName}
                  className="w-9 h-9 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                />
              </button>

              {showProfileMenu && (
                <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl shadow-2xl z-50 py-2 text-xs">
                  
                  {/* User Badge Header */}
                  <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-700/60">
                    <p className="font-bold text-slate-900 dark:text-white truncate">{user.displayName}</p>
                    <p className="text-slate-400 truncate">{user.email}</p>
                  </div>

                  <button
                    onClick={() => {
                      setShowProfileMenu(false);
                      setActiveView('profile', user.uid);
                    }}
                    className="w-full flex items-center px-4 py-2.5 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 font-semibold"
                  >
                    <User className="w-4 h-4 mr-2 text-blue-500" />
                    My Profile
                  </button>

                  <button
                    onClick={() => {
                      setShowProfileMenu(false);
                      setActiveView('settings');
                    }}
                    className="w-full flex items-center px-4 py-2.5 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 font-semibold"
                  >
                    <Settings className="w-4 h-4 mr-2 text-indigo-500" />
                    Settings
                  </button>

                  <button
                    onClick={() => {
                      setShowProfileMenu(false);
                      setIsApkModalOpen(true);
                    }}
                    className="w-full flex items-center px-4 py-2.5 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 font-semibold md:hidden"
                  >
                    <Smartphone className="w-4 h-4 mr-2 text-emerald-500" />
                    Download Android APK
                  </button>

                  <div className="my-1 border-t border-slate-100 dark:border-slate-700/60" />

                  <button
                    onClick={() => {
                      setShowProfileMenu(false);
                      logout();
                    }}
                    className="w-full flex items-center px-4 py-2.5 text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 font-semibold"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </button>

                </div>
              )}
            </div>
          )}

        </div>

      </div>
    </header>
  );
};
