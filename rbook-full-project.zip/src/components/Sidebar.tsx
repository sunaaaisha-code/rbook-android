import React from 'react';
import { 
  Home, 
  User, 
  MessageSquare, 
  Bell, 
  Search, 
  Settings, 
  Smartphone, 
  LogOut, 
  Sparkles,
  ShieldAlert,
  Users
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface SidebarProps {
  isMobileOpen?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isMobileOpen, onCloseMobile }) => {
  const { 
    user, 
    activeView, 
    setActiveView, 
    unreadNotifCount, 
    setIsApkModalOpen, 
    logout 
  } = useAuth();

  const navItems = [
    { id: 'feed', label: 'Home Feed', icon: Home },
    { id: 'profile', label: 'My Profile', icon: User, targetUid: user?.uid },
    { id: 'chat', label: '1-to-1 Chat', icon: MessageSquare },
    { id: 'notifications', label: 'Notifications', icon: Bell, badge: unreadNotifCount },
    { id: 'search', label: 'Search Users', icon: Search },
    { id: 'settings', label: 'Settings & Privacy', icon: Settings }
  ];

  const content = (
    <div className="flex flex-col h-full space-y-6">
      
      {/* User Mini Card */}
      {user && (
        <div 
          onClick={() => {
            setActiveView('profile', user.uid);
            onCloseMobile?.();
          }}
          className="p-3 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-slate-800 dark:to-slate-800/80 rounded-2xl border border-blue-100 dark:border-slate-700/60 flex items-center space-x-3 cursor-pointer group transition-all hover:shadow-md"
        >
          <img
            src={user.photoURL}
            alt={user.displayName}
            className="w-12 h-12 rounded-full object-cover border-2 border-white dark:border-slate-900 shadow-sm"
          />
          <div className="overflow-hidden">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white truncate group-hover:text-blue-600 transition-colors">
              {user.displayName}
            </h3>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">@{user.email.split('@')[0]}</p>
            <div className="flex items-center space-x-3 mt-1 text-[10px] text-slate-500 font-semibold">
              <span>{user.followersCount || 0} followers</span>
              <span>•</span>
              <span>{user.followingCount || 0} following</span>
            </div>
          </div>
        </div>
      )}

      {/* Main Nav Links */}
      <nav className="space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;

          return (
            <button
              key={item.id}
              onClick={() => {
                setActiveView(item.id as any, item.targetUid);
                onCloseMobile?.();
              }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl text-xs font-bold transition-all ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <div className="flex items-center space-x-3">
                <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-slate-500 dark:text-slate-400'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && item.badge > 0 && (
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold ${
                  isActive ? 'bg-white text-blue-600' : 'bg-rose-600 text-white'
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Android Build Callout Banner */}
      <div className="p-4 bg-gradient-to-br from-emerald-500 to-teal-600 text-white rounded-2xl shadow-lg shadow-emerald-500/15 space-y-2">
        <div className="flex items-center space-x-2">
          <Smartphone className="w-5 h-5" />
          <h4 className="text-xs font-bold">RBook Android App</h4>
        </div>
        <p className="text-[11px] text-emerald-100 leading-tight">
          Ready to run on your phone. Get native APK package commands or install PWA.
        </p>
        <button
          onClick={() => {
            setIsApkModalOpen(true);
            onCloseMobile?.();
          }}
          className="w-full mt-2 py-2 bg-white hover:bg-emerald-50 text-emerald-800 rounded-xl text-xs font-extrabold shadow-sm transition-colors"
        >
          Download / Build APK
        </button>
      </div>

      {/* Footer Logout */}
      <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
        <button
          onClick={logout}
          className="w-full flex items-center space-x-3 px-4 py-3 text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-2xl text-xs font-bold transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span>Logout</span>
        </button>
      </div>

    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden md:block w-64 shrink-0 py-6 pr-4">
        <div className="sticky top-20 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-4 shadow-sm">
          {content}
        </div>
      </aside>

      {/* Mobile Drawer Overlay */}
      {isMobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden bg-black/60 backdrop-blur-sm flex">
          <div className="w-72 bg-white dark:bg-slate-900 h-full p-4 overflow-y-auto border-r border-slate-200 dark:border-slate-800 shadow-2xl">
            <div className="flex justify-end pb-2">
              <button onClick={onCloseMobile} className="p-1 rounded-full text-slate-400 hover:text-slate-600">✕</button>
            </div>
            {content}
          </div>
          <div className="flex-1" onClick={onCloseMobile} />
        </div>
      )}
    </>
  );
};
