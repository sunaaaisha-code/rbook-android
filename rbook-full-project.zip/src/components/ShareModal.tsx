import React, { useState } from 'react';
import { X, Copy, Check, Share2, Repeat } from 'lucide-react';
import { Post } from '../types';
import { sharePost, createPost } from '../services/db';
import { useAuth } from '../context/AuthContext';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  post: Post | null;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose, post }) => {
  const { user } = useAuth();
  const [copied, setCopied] = useState(false);
  const [reposting, setReposting] = useState(false);
  const [reposted, setReposted] = useState(false);

  if (!isOpen || !post || !user) return null;

  const shareUrl = `${window.location.origin}/post/${post.id}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Post by ${post.authorName} on RBook`,
          text: post.content,
          url: shareUrl
        });
      } catch (e) {
        // ignore user cancel
      }
    } else {
      handleCopyLink();
    }
  };

  const handleRepostToFeed = async () => {
    setReposting(true);
    try {
      await createPost({
        authorId: user.uid,
        authorName: user.displayName,
        authorPhoto: user.photoURL,
        content: `Reposted from @${post.authorName}:\n"${post.content}"`,
        mediaType: post.mediaType,
        mediaUrl: post.mediaUrl
      });
      await sharePost(post.id);
      setReposting(false);
      setReposted(true);
      setTimeout(() => {
        setReposted(false);
        onClose();
      }, 1500);
    } catch (e) {
      setReposting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center">
            <Share2 className="w-5 h-5 text-blue-600 mr-2" />
            Share Post
          </h2>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          
          {/* Post Snippet */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60 flex items-start space-x-3">
            <img src={post.authorPhoto} alt="" className="w-9 h-9 rounded-full object-cover shrink-0" />
            <div className="overflow-hidden">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">{post.authorName}</h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 mt-0.5">{post.content}</p>
            </div>
          </div>

          {/* Share Actions */}
          <div className="space-y-2">
            
            {/* Repost to Feed */}
            <button
              onClick={handleRepostToFeed}
              disabled={reposting || reposted}
              className="w-full flex items-center justify-between p-3 rounded-xl border border-blue-200 dark:border-blue-900 bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 text-blue-900 dark:text-blue-200 text-xs font-semibold transition-all"
            >
              <div className="flex items-center space-x-2">
                <Repeat className="w-4 h-4 text-blue-600" />
                <span>{reposted ? 'Reposted to your feed!' : 'Repost to my Feed'}</span>
              </div>
              {reposting && <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />}
            </button>

            {/* Copy Link */}
            <button
              onClick={handleCopyLink}
              className="w-full flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-semibold transition-all"
            >
              <div className="flex items-center space-x-2">
                {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4 text-slate-500" />}
                <span>{copied ? 'Link Copied to Clipboard!' : 'Copy Direct Link'}</span>
              </div>
            </button>

            {/* Native Mobile Share */}
            {navigator.share && (
              <button
                onClick={handleNativeShare}
                className="w-full flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 text-xs font-semibold transition-all"
              >
                <div className="flex items-center space-x-2">
                  <Share2 className="w-4 h-4 text-indigo-500" />
                  <span>Share via Apps (WhatsApp, Twitter, Email)</span>
                </div>
              </button>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};
