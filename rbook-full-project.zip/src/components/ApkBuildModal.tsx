import React, { useState } from 'react';
import { Smartphone, Download, ShieldCheck, Terminal, Copy, Check, Sparkles, Layers } from 'lucide-react';

interface ApkBuildModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkBuildModal: React.FC<ApkBuildModalProps> = ({ isOpen, onClose }) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [downloadingFile, setDownloadingFile] = useState<string | null>(null);
  const [downloadStatus, setDownloadStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  if (!isOpen) return null;

  const buildCommands = [
    'npm run build',
    'npm install @capacitor/core @capacitor/cli @capacitor/android',
    'npx cap init RBook com.rbook.app --web-dir dist',
    'npx cap add android',
    'npx cap open android'
  ];

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleDownloadZip = async (zipUrl: string, filename: string) => {
    setDownloadingFile(filename);
    setDownloadStatus(null);

    try {
      // 1. Fetch file as blob directly
      const response = await fetch(zipUrl, { cache: 'no-cache' });
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const blob = await response.blob();
      
      // 2. Create in-memory Blob URL
      const blobUrl = window.URL.createObjectURL(blob);

      // 3. Trigger programmatic download
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // 4. Clean up Blob URL
      setTimeout(() => {
        window.URL.revokeObjectURL(blobUrl);
      }, 10000);

      setDownloadStatus({
        type: 'success',
        message: `Successfully downloaded ${filename} (${(blob.size / 1024 / 1024).toFixed(2)} MB)!`
      });
    } catch (error: any) {
      console.error('ZIP download error:', error);
      // Fallback: direct window download trigger
      try {
        const link = document.createElement('a');
        link.href = zipUrl;
        link.download = filename;
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setDownloadStatus({
          type: 'success',
          message: `Initiated download for ${filename}`
        });
      } catch (fallbackErr) {
        setDownloadStatus({
          type: 'error',
          message: 'Could not download ZIP file. Please try again.'
        });
      }
    } finally {
      setDownloadingFile(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800 my-8">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-6 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-white/10 backdrop-blur-md rounded-xl">
              <Smartphone className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold">RBook Android APK Build Center</h2>
              <p className="text-blue-100 text-xs mt-0.5">Production-ready mobile export & Capacitor build pipeline</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto text-slate-800 dark:text-slate-200">
          
          {/* Direct Mobile App Installation & ZIP Download */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/40 dark:to-indigo-950/30 border border-blue-200 dark:border-blue-900/60 rounded-2xl p-5 shadow-sm space-y-4">
            <div>
              <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 mb-2">
                <Sparkles className="w-3.5 h-3.5 mr-1.5 text-blue-600" /> Complete Android Project & ZIP Export
              </span>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Download Real Android Project ZIP</h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                Download the complete pre-configured Capacitor Android project (`com.rbook.app`). Open directly in <strong className="text-slate-900 dark:text-white">AndroidIDE</strong> or <strong className="text-slate-900 dark:text-white">Android Studio</strong> on your phone or PC to build the release APK immediately.
              </p>
            </div>

            {downloadStatus && (
              <div className={`p-3 rounded-xl text-xs font-semibold flex items-center space-x-2 ${
                downloadStatus.type === 'success' 
                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-200 border border-emerald-300 dark:border-emerald-800' 
                  : 'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-200 border border-rose-300 dark:border-rose-800'
              }`}>
                {downloadStatus.type === 'success' ? (
                  <Check className="w-4 h-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
                ) : (
                  <ShieldCheck className="w-4 h-4 shrink-0 text-rose-600 dark:text-rose-400" />
                )}
                <span>{downloadStatus.message}</span>
              </div>
            )}

            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => handleDownloadZip('/rbook-android.zip', 'rbook-android.zip')}
                disabled={downloadingFile !== null}
                className="flex items-center px-4 py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white font-bold rounded-xl text-xs transition-all shadow-md shadow-blue-500/20 disabled:opacity-60"
              >
                {downloadingFile === 'rbook-android.zip' ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Downloading Android Project...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 mr-2" />
                    Download AndroidIDE Project (.zip)
                  </>
                )}
              </button>

              <button
                onClick={() => handleDownloadZip('/rbook-full-project.zip', 'rbook-full-project.zip')}
                disabled={downloadingFile !== null}
                className="flex items-center px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 font-bold rounded-xl text-xs transition-all border border-slate-300 dark:border-slate-700 disabled:opacity-60"
              >
                {downloadingFile === 'rbook-full-project.zip' ? (
                  <>
                    <div className="w-4 h-4 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mr-2" />
                    Downloading Full Source...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 mr-2 text-indigo-500" />
                    Download Full Source (.zip)
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  if ('serviceWorker' in navigator && (window as any).deferredPrompt) {
                    (window as any).deferredPrompt.prompt();
                  } else {
                    alert('To install RBook on Android: Open in Chrome Mobile -> Tap 3-dots menu -> Select "Add to Home screen / Install App"');
                  }
                }}
                className="flex items-center px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 font-bold rounded-xl text-xs transition-all border border-slate-300 dark:border-slate-700"
              >
                <Smartphone className="w-4 h-4 mr-2 text-emerald-500" />
                Install Mobile PWA
              </button>
            </div>
          </div>

          {/* Capacitor Native APK Build Instructions */}
          <div className="space-y-3">
            <h3 className="text-base font-bold flex items-center text-slate-900 dark:text-white">
              <Terminal className="w-5 h-5 text-indigo-500 mr-2" />
              Build Native Android APK (.apk / .aab)
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Run these simple commands in your terminal to build the compiled native Android studio app package:
            </p>

            <div className="bg-slate-900 text-slate-100 rounded-xl p-4 font-mono text-xs space-y-2 border border-slate-800 shadow-inner">
              {buildCommands.map((cmd, idx) => (
                <div key={idx} className="flex items-center justify-between group py-1 border-b border-slate-800/60 last:border-0">
                  <div className="flex items-center space-x-2 overflow-x-auto">
                    <span className="text-blue-400 select-none">$</span>
                    <span className="text-slate-200">{cmd}</span>
                  </div>
                  <button
                    onClick={() => handleCopy(cmd, idx)}
                    className="p-1 text-slate-400 hover:text-white bg-slate-800 rounded transition-colors ml-2"
                    title="Copy command"
                  >
                    {copiedIndex === idx ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Key Features Summary */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60 flex items-start space-x-3">
              <ShieldCheck className="w-5 h-5 text-emerald-500 mt-0.5 shrink-0" />
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">Secure Firebase Cloud Backend</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Firebase Auth & Firestore live data rules active.</p>
              </div>
            </div>
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60 flex items-start space-x-3">
              <Layers className="w-5 h-5 text-indigo-500 mt-0.5 shrink-0" />
              <div>
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">Full Stack Responsiveness</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Optimized for phones, tablets and desktops.</p>
              </div>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="bg-slate-50 dark:bg-slate-800/50 p-4 px-6 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-100 text-sm font-medium rounded-xl transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
