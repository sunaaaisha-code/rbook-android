import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  MoreHorizontal, 
  Trash2, 
  Flag, 
  Send, 
  Play, 
  UserCheck, 
  UserPlus, 
  ShieldAlert,
  Clock
} from 'lucide-react';
import { Post, Comment, UserProfile } from '../types';
import { useAuth } from '../context/AuthContext';
import { 
  toggleLikePost, 
  subscribeToComments, 
  addComment, 
  deleteComment, 
  deletePost, 
  getUserProfile 
} from '../services/db';
import { ShareModal } from './ShareModal';
import { ReportModal } from './ReportModal';

interface PostCardProps {
  post: Post;
}

export const PostCard: React.FC<PostCardProps> = ({ post }) => {
  const { user, setActiveView } = useAuth();
  
  const [authorProfile, setAuthorProfile] = useState<UserProfile | null>(null);
  const [isLiked, setIsLiked] = useState<boolean>(false);
  const [likesCount, setLikesCount] = useState<number>(post.likesCount || 0);
  const [showComments, setShowComments] = useState<boolean>(false);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newCommentText, setNewCommentText] = useState<string>('');
  const [submittingComment, setSubmittingComment] = useState<boolean>(false);
  
  const [showDropdown, setShowDropdown] = useState<boolean>(false);
  const [showShareModal, setShowShareModal] = useState<boolean>(false);
  const [showReportModal, setShowReportModal] = useState<boolean>(false);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  // Sync likes state with user
  useEffect(() => {
    if (user) {
      setIsLiked(post.likes?.includes(user.uid) || false);
    }
    setLikesCount(post.likesCount || 0);
  }, [post, user]);

  // Fetch author online status
  useEffect(() => {
    let isMounted = true;
    getUserProfile(post.authorId).then((p) => {
      if (isMounted && p) setAuthorProfile(p);
    });
    return () => { isMounted = false; };
  }, [post.authorId]);

  // Subscribe to comments if expanded
  useEffect(() => {
    if (!showComments) return;
    const unsub = subscribeToComments(post.id, (cmts) => {
      setComments(cmts);
    });
    return () => unsub();
  }, [post.id, showComments]);

  const handleLikeToggle = async () => {
    if (!user) return;
    const newLikedState = !isLiked;
    setIsLiked(newLikedState);
    setLikesCount((prev) => (newLikedState ? prev + 1 : prev - 1));

    await toggleLikePost(
      post.id, 
      user.uid, 
      isLiked, 
      post.authorId, 
      user.displayName, 
      user.photoURL
    );
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim() || !user) return;

    setSubmittingComment(true);
    try {
      await addComment({
        postId: post.id,
        authorId: user.uid,
        authorName: user.displayName,
        authorPhoto: user.photoURL,
        text: newCommentText.trim(),
        postAuthorId: post.authorId
      });
      setNewCommentText('');
      setSubmittingComment(false);
    } catch (e) {
      setSubmittingComment(false);
    }
  };

  const handleDeleteComment = async (commentId: string) => {
    if (window.confirm('Delete this comment?')) {
      await deleteComment(commentId, post.id);
    }
  };

  const handleDeletePost = async () => {
    if (window.confirm('Are you sure you want to delete this post?')) {
      setIsDeleting(true);
      try {
        await deletePost(post.id);
      } catch (e) {
        setIsDeleting(false);
      }
    }
  };

  const formattedTime = post.createdAt
    ? new Date(post.createdAt).toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })
    : 'Just now';

  if (isDeleting) return null;

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden transition-all hover:border-slate-300 dark:hover:border-slate-700 mb-4">
      
      {/* Post Header */}
      <div className="p-4 flex items-center justify-between">
        <div 
          onClick={() => setActiveView('profile', post.authorId)}
          className="flex items-center space-x-3 cursor-pointer group"
        >
          <div className="relative">
            <img
              src={post.authorPhoto || authorProfile?.photoURL}
              alt={post.authorName}
              className="w-11 h-11 rounded-full object-cover border border-slate-200 dark:border-slate-700 group-hover:opacity-90 transition-opacity"
            />
            {authorProfile?.online && (
              <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-white dark:border-slate-900 rounded-full" title="Online" />
            )}
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors flex items-center">
              {post.authorName}
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center mt-0.5">
              <Clock className="w-3 h-3 mr-1 text-slate-400" />
              {formattedTime}
            </p>
          </div>
        </div>

        {/* Post Dropdown Menu */}
        <div className="relative">
          <button
            onClick={() => setShowDropdown(!showDropdown)}
            className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 transition-colors"
          >
            <MoreHorizontal className="w-5 h-5" />
          </button>

          {showDropdown && (
            <div className="absolute right-0 mt-1 w-44 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl z-20 py-1 text-xs">
              {user?.uid === post.authorId ? (
                <button
                  onClick={() => {
                    setShowDropdown(false);
                    handleDeletePost();
                  }}
                  className="w-full flex items-center px-4 py-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 font-semibold"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Post
                </button>
              ) : (
                <button
                  onClick={() => {
                    setShowDropdown(false);
                    setShowReportModal(true);
                  }}
                  className="w-full flex items-center px-4 py-2 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 font-semibold"
                >
                  <Flag className="w-4 h-4 mr-2 text-amber-500" />
                  Report Post
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Post Text Body */}
      {post.content && (
        <div className="px-4 pb-3">
          <p className="text-sm text-slate-800 dark:text-slate-100 whitespace-pre-wrap leading-relaxed">
            {post.content}
          </p>
        </div>
      )}

      {/* Post Media (Photo / Video) */}
      {post.mediaType !== 'none' && post.mediaUrl && (
        <div className="bg-slate-950 flex items-center justify-center overflow-hidden max-h-[500px]">
          {post.mediaType === 'image' ? (
            <img
              src={post.mediaUrl}
              alt="Post attachment"
              className="w-full h-auto max-h-[500px] object-contain"
            />
          ) : (
            <video
              src={post.mediaUrl}
              controls
              playsInline
              className="w-full max-h-[500px]"
            />
          )}
        </div>
      )}

      {/* Action Buttons & Counters Bar */}
      <div className="px-4 py-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-300">
        
        {/* Like Button */}
        <button
          onClick={handleLikeToggle}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl transition-all ${
            isLiked
              ? 'text-rose-600 bg-rose-50 dark:bg-rose-950/40'
              : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300'
          }`}
        >
          <Heart className={`w-4 h-4 ${isLiked ? 'fill-rose-600 text-rose-600' : ''}`} />
          <span>{likesCount} Likes</span>
        </button>

        {/* Comment Button */}
        <button
          onClick={() => setShowComments(!showComments)}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <MessageCircle className="w-4 h-4 text-blue-500" />
          <span>{post.commentsCount || comments.length} Comments</span>
        </button>

        {/* Share Button */}
        <button
          onClick={() => setShowShareModal(true)}
          className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <Share2 className="w-4 h-4 text-indigo-500" />
          <span>{post.sharesCount || 0} Shares</span>
        </button>
      </div>

      {/* Comments Drawer Section */}
      {showComments && (
        <div className="bg-slate-50 dark:bg-slate-900/60 p-4 border-t border-slate-200 dark:border-slate-800 space-y-4">
          
          {/* Add Comment Input */}
          {user && (
            <form onSubmit={handleAddComment} className="flex items-center space-x-2">
              <img src={user.photoURL} alt="" className="w-8 h-8 rounded-full object-cover shrink-0" />
              <input
                type="text"
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                placeholder="Write a comment..."
                className="flex-1 px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="submit"
                disabled={submittingComment || !newCommentText.trim()}
                className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl transition-all disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* Comments List */}
          <div className="space-y-3 max-h-60 overflow-y-auto pt-1">
            {comments.length === 0 ? (
              <p className="text-center text-xs text-slate-400 py-2">No comments yet. Be the first to comment!</p>
            ) : (
              comments.map((c) => (
                <div key={c.id} className="flex items-start space-x-2 group">
                  <img src={c.authorPhoto} alt="" className="w-7 h-7 rounded-full object-cover shrink-0 mt-0.5" />
                  <div className="flex-1 bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700/60 text-xs">
                    <div className="flex items-center justify-between">
                      <span 
                        onClick={() => setActiveView('profile', c.authorId)}
                        className="font-bold text-slate-900 dark:text-white cursor-pointer hover:underline"
                      >
                        {c.authorName}
                      </span>
                      {user?.uid === c.authorId && (
                        <button
                          onClick={() => handleDeleteComment(c.id)}
                          className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-500 transition-opacity"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                    <p className="text-slate-700 dark:text-slate-300 mt-1">{c.text}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Share Modal */}
      <ShareModal
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
        post={post}
      />

      {/* Report Modal */}
      <ReportModal
        isOpen={showReportModal}
        onClose={() => setShowReportModal(false)}
        targetType="post"
        targetId={post.id}
        targetName={`Post by ${post.authorName}`}
      />

    </div>
  );
};
