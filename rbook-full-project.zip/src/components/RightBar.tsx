import React, { useEffect, useState } from 'react';
import { UserPlus, UserCheck, MessageSquare, TrendingUp, Sparkles } from 'lucide-react';
import { UserProfile } from '../types';
import { useAuth } from '../context/AuthContext';
import { searchUsers, toggleFollowUser } from '../services/db';

export const RightBar: React.FC = () => {
  const { user, setActiveView, openChatWithUser, refreshUserProfile } = useAuth();
  const [recommendedUsers, setRecommendedUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    searchUsers('a').then((users) => {
      if (isMounted) {
        // filter out current user and already blocked users
        const filtered = users.filter((u) => u.uid !== user?.uid && !user?.blockedUsers?.includes(u.uid));
        setRecommendedUsers(filtered.slice(0, 5));
        setLoading(false);
      }
    });
    return () => { isMounted = false; };
  }, [user]);

  const handleToggleFollow = async (targetUser: UserProfile) => {
    if (!user) return;
    const isFollowing = user.following?.includes(targetUser.uid) || false;
    await toggleFollowUser(user.uid, targetUser.uid, isFollowing, user.displayName, user.photoURL);
    await refreshUserProfile();
  };

  const trendingTopics = [
    { tag: '#RBookLaunch', posts: '14.2K posts' },
    { tag: '#TechInnovation', posts: '8.9K posts' },
    { tag: '#Web3AndAI', posts: '5.1K posts' },
    { tag: '#Photography', posts: '12.4K posts' }
  ];

  return (
    <aside className="hidden lg:block w-80 shrink-0 py-6 pl-4">
      <div className="sticky top-20 space-y-6">
        
        {/* Recommended People to Follow */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center">
              <Sparkles className="w-4 h-4 text-blue-600 mr-1.5" />
              Suggested For You
            </h3>
            <button
              onClick={() => setActiveView('search')}
              className="text-[11px] font-bold text-blue-600 hover:underline"
            >
              See All
            </button>
          </div>

          <div className="space-y-3">
            {loading ? (
              <div className="py-4 text-center">
                <div className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
              </div>
            ) : recommendedUsers.length === 0 ? (
              <p className="text-xs text-slate-400 py-2">No recommendations available right now.</p>
            ) : (
              recommendedUsers.map((u) => {
                const isFollowing = user?.following?.includes(u.uid) || false;

                return (
                  <div key={u.uid} className="flex items-center justify-between">
                    <div 
                      onClick={() => setActiveView('profile', u.uid)}
                      className="flex items-center space-x-2.5 cursor-pointer overflow-hidden flex-1 mr-2"
                    >
                      <div className="relative">
                        <img src={u.photoURL} alt={u.displayName} className="w-9 h-9 rounded-full object-cover shrink-0 border border-slate-200 dark:border-slate-700" />
                        {u.online && <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border-2 border-white dark:border-slate-900 rounded-full" />}
                      </div>
                      <div className="truncate">
                        <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate hover:underline">{u.displayName}</h4>
                        <p className="text-[10px] text-slate-400 truncate">{u.bio || 'New RBook member'}</p>
                      </div>
                    </div>

                    <button
                      onClick={() => handleToggleFollow(u)}
                      className={`p-1.5 rounded-xl text-xs font-semibold flex items-center transition-all ${
                        isFollowing
                          ? 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                          : 'bg-blue-600 hover:bg-blue-700 text-white'
                      }`}
                      title={isFollowing ? 'Following' : 'Follow'}
                    >
                      {isFollowing ? <UserCheck className="w-4 h-4 text-emerald-500" /> : <UserPlus className="w-4 h-4" />}
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Trending Topics */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center mb-3">
            <TrendingUp className="w-4 h-4 text-indigo-500 mr-1.5" />
            Trending Topics
          </h3>
          <div className="space-y-3">
            {trendingTopics.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between py-1 border-b border-slate-100 dark:border-slate-800/60 last:border-0">
                <div>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white hover:text-blue-600 transition-colors cursor-pointer">
                    {item.tag}
                  </h4>
                  <p className="text-[10px] text-slate-400">{item.posts}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </aside>
  );
};
