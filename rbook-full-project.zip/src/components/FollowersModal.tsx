import React, { useEffect, useState } from 'react';
import { X, UserPlus, UserCheck, MessageSquare } from 'lucide-react';
import { UserProfile } from '../types';
import { getUserProfile, toggleFollowUser } from '../services/db';
import { useAuth } from '../context/AuthContext';

interface FollowersModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: 'Followers' | 'Following';
  userIds: string[];
}

export const FollowersModal: React.FC<FollowersModalProps> = ({
  isOpen,
  onClose,
  title,
  userIds
}) => {
  const { user, setActiveView, openChatWithUser, refreshUserProfile } = useAuth();
  const [usersList, setUsersList] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isOpen) return;
    let isMounted = true;
    setLoading(true);

    const fetchUsers = async () => {
      const profiles: UserProfile[] = [];
      for (const id of userIds) {
        const p = await getUserProfile(id);
        if (p) profiles.push(p);
      }
      if (isMounted) {
        setUsersList(profiles);
        setLoading(false);
      }
    };

    fetchUsers();
    return () => { isMounted = false; };
  }, [isOpen, userIds]);

  if (!isOpen) return null;

  const handleToggleFollow = async (targetUser: UserProfile) => {
    if (!user) return;
    const isFollowing = user.following?.includes(targetUser.uid) || false;
    await toggleFollowUser(user.uid, targetUser.uid, isFollowing, user.displayName, user.photoURL);
    await refreshUserProfile();
    // Update local state display
    setUsersList((prev) =>
      prev.map((u) => {
        if (u.uid === targetUser.uid) {
          return {
            ...u,
            followersCount: isFollowing ? u.followersCount - 1 : u.followersCount + 1
          };
        }
        return u;
      })
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {title} ({userIds.length})
          </h2>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 max-h-96 overflow-y-auto space-y-3">
          {loading ? (
            <div className="py-8 text-center">
              <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
            </div>
          ) : usersList.length === 0 ? (
            <p className="py-8 text-center text-xs text-slate-500">No users found.</p>
          ) : (
            usersList.map((u) => {
              const isFollowing = user?.following?.includes(u.uid) || false;
              const isSelf = user?.uid === u.uid;

              return (
                <div key={u.uid} className="flex items-center justify-between p-2 hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-xl transition-colors">
                  <div 
                    onClick={() => {
                      onClose();
                      setActiveView('profile', u.uid);
                    }}
                    className="flex items-center space-x-3 cursor-pointer overflow-hidden flex-1"
                  >
                    <div className="relative">
                      <img src={u.photoURL} alt={u.displayName} className="w-10 h-10 rounded-full object-cover shrink-0" />
                      {u.online && <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white dark:border-slate-900 rounded-full" />}
                    </div>
                    <div className="truncate">
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white hover:underline truncate">{u.displayName}</h4>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">{u.bio || u.email}</p>
                    </div>
                  </div>

                  {!isSelf && user && (
                    <div className="flex items-center space-x-2 shrink-0 ml-2">
                      <button
                        onClick={() => {
                          onClose();
                          openChatWithUser(u.uid);
                        }}
                        className="p-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl transition-colors"
                        title="Chat"
                      >
                        <MessageSquare className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => handleToggleFollow(u)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center transition-all ${
                          isFollowing
                            ? 'bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200'
                            : 'bg-blue-600 hover:bg-blue-700 text-white shadow-sm'
                        }`}
                      >
                        {isFollowing ? (
                          <>
                            <UserCheck className="w-3.5 h-3.5 mr-1" />
                            Following
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-3.5 h-3.5 mr-1" />
                            Follow
                          </>
                        )}
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
