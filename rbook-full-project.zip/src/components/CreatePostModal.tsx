import React, { useState, useRef } from 'react';
import { Image, Video, X, Sparkles, AlertCircle, Upload, Check } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { createPost } from '../services/db';

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const PRESET_IMAGES = [
  'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1000&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1000&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1000&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1518770660439-4636190af475?w=1000&auto=format&fit=crop&q=80'
];

const PRESET_VIDEOS = [
  'https://assets.mixkit.co/videos/preview/mixkit-working-overtime-in-a-modern-office-42511-large.mp4',
  'https://assets.mixkit.co/videos/preview/mixkit-set-of-plateaus-seen-from-the-sky-in-a-sunset-26070-large.mp4'
];

export const CreatePostModal: React.FC<CreatePostModalProps> = ({ isOpen, onClose }) => {
  const { user } = useAuth();
  const [content, setContent] = useState('');
  const [mediaType, setMediaType] = useState<'image' | 'video' | 'none'>('none');
  const [mediaUrl, setMediaUrl] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [showPresets, setShowPresets] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen || !user) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isVideo = file.type.startsWith('video/');
    const isImage = file.type.startsWith('image/');

    if (!isImage && !isVideo) {
      setError('Please select an image or video file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setMediaUrl(reader.result as string);
      setMediaType(isVideo ? 'video' : 'image');
      setError('');
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim() && mediaType === 'none') {
      setError('Please enter some text or attach media to post.');
      return;
    }

    setSubmitting(true);
    setError('');

    try {
      await createPost({
        authorId: user.uid,
        authorName: user.displayName,
        authorPhoto: user.photoURL,
        content: content.trim(),
        mediaType,
        mediaUrl: mediaType !== 'none' ? mediaUrl : undefined
      });

      setContent('');
      setMediaType('none');
      setMediaUrl('');
      setSubmitting(false);
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Failed to publish post. Please try again.');
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center">
            Create Post
          </h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-500 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          {/* Author Info */}
          <div className="flex items-center space-x-3">
            <img
              src={user.photoURL}
              alt={user.displayName}
              className="w-11 h-11 rounded-full object-cover border border-slate-200 dark:border-slate-700"
            />
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">{user.displayName}</h3>
              <span className="text-xs text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950 px-2 py-0.5 rounded-full">
                Public Feed
              </span>
            </div>
          </div>

          {/* Text Content */}
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={`What's on your mind, ${user.displayName.split(' ')[0]}?`}
            rows={4}
            className="w-full text-slate-900 dark:text-slate-100 placeholder-slate-400 bg-transparent border-0 resize-none focus:outline-none focus:ring-0 text-base"
          />

          {/* Error Message */}
          {error && (
            <div className="p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-600 dark:text-red-400 rounded-xl text-xs flex items-center">
              <AlertCircle className="w-4 h-4 mr-2 shrink-0" />
              {error}
            </div>
          )}

          {/* Media Preview */}
          {mediaType !== 'none' && mediaUrl && (
            <div className="relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-black max-h-60 flex items-center justify-center">
              <button
                type="button"
                onClick={() => {
                  setMediaType('none');
                  setMediaUrl('');
                }}
                className="absolute top-2 right-2 p-1.5 bg-black/70 hover:bg-black/90 text-white rounded-full transition-colors z-10"
              >
                <X className="w-4 h-4" />
              </button>
              {mediaType === 'image' ? (
                <img src={mediaUrl} alt="Upload preview" className="max-h-60 w-auto object-contain" />
              ) : (
                <video src={mediaUrl} controls className="max-h-60 w-full" />
              )}
            </div>
          )}

          {/* Stock Media Presets Selector */}
          {showPresets && (
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
                <span>Select Stock Photo / Video</span>
                <button type="button" onClick={() => setShowPresets(false)} className="text-slate-400 hover:text-slate-600">✕</button>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {PRESET_IMAGES.map((img, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => {
                      setMediaUrl(img);
                      setMediaType('image');
                      setShowPresets(false);
                    }}
                    className="relative rounded-lg overflow-hidden h-16 border border-slate-300 dark:border-slate-600 hover:opacity-80 transition-opacity"
                  >
                    <img src={img} alt="Stock" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
              <div className="flex space-x-2">
                {PRESET_VIDEOS.map((vid, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => {
                      setMediaUrl(vid);
                      setMediaType('video');
                      setShowPresets(false);
                    }}
                    className="flex-1 py-1.5 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 rounded-lg text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center justify-center"
                  >
                    <Video className="w-3.5 h-3.5 mr-1 text-indigo-500" />
                    Stock Video {i + 1}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Hidden File Input */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="image/*,video/*"
            className="hidden"
          />

          {/* Actions Toolbar */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center space-x-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
              >
                <Image className="w-4 h-4 text-emerald-500" />
                <span>Photo/Video</span>
              </button>

              <button
                type="button"
                onClick={() => setShowPresets(!showPresets)}
                className="flex items-center space-x-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
              >
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>Stock Library</span>
              </button>
            </div>

            <button
              type="submit"
              disabled={submitting || (!content.trim() && mediaType === 'none')}
              className="px-5 py-2 bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-sm font-medium rounded-xl transition-all shadow-md shadow-blue-500/20 disabled:opacity-50 disabled:pointer-events-none"
            >
              {submitting ? 'Posting...' : 'Post'}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
